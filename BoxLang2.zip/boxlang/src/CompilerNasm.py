#!/usr/bin/python3

import struct
from lib.TokenType import TokenType
from lib import AST

class CompilerNasm:
    def __init__(self, error_handler, target_bits=16):
        self.error_handler = error_handler
        self.target_bits = target_bits
        self.nasm_code = ""
        self.data_section = ""
        
        # Системы управления переменными и функциями
        self.global_variables = {}  # {"var_name": ("type", "label", size)}
        self.local_variables = {}   # {"var_name": ("type", offset_from_bp, size)}
        self.function_signatures = {}  # {"func_name": {"params": [...], "return_type": ...}}
        self.array_sizes = {}       # {"array_name": size}
        
        # НОВОЕ: Поддержка структур
        self.struct_definitions = {}  # {"struct_name": {"size": total_size, "fields": {...}}}
        
        # Счётчики для уникальных меток
        self.label_counter = 0
        self.string_counter = 0
        self.current_function = None
        
        # Настройки архитектуры
        self.main_reg = "ax" if target_bits == 16 else "eax"
        self.base_reg = "bp" if target_bits == 16 else "ebp" 
        self.stack_reg = "sp" if target_bits == 16 else "esp"
        self.temp_reg = "bx" if target_bits == 16 else "ebx"
        self.addr_reg = "bx" if target_bits == 16 else "ebx"

    def emit(self, code):
        """Добавляет код в выходной поток"""
        self.nasm_code += code

    def emit_data(self, data):
        """Добавляет данные в секцию данных"""
        self.data_section += data

    def get_label(self, prefix="L"):
        """Генерирует уникальную метку"""
        label = f"{prefix}_{self.label_counter}"
        self.label_counter += 1
        return label

    def compile(self, ast, std_lib_code=""):
        """Главная функция компиляции"""
        # Заголовок NASM
        self.emit(f"BITS {self.target_bits}\n")
        self.emit("ORG 0x8000\n\n")
        self.emit("section .text\n\n")
        self.emit("jmp _start\n")
        
        # Сначала обрабатываем объявления структур
        for node in ast.statements:
            if isinstance(node, AST.StructDeclarationNode):
                self.visit(node)
        
        # Затем глобальные объявления переменных
        for node in ast.statements:
            if isinstance(node, (AST.VariableDeclarationNode, AST.ArrayDeclarationNode)):
                self.visit_global_declaration(node)
        
        # Затем функции
        for node in ast.statements:
            if isinstance(node, AST.FunctionDeclarationNode):
                self.visit(node)
        
        # Добавляем секцию данных
        if self.data_section:
            self.emit("\n; == DATA SECTION ==\n")
            self.emit(self.data_section)
        
        return self.nasm_code

    def visit(self, node):
        """Диспетчер для обработки узлов AST"""
        method_name = f'visit_{type(node).__name__}'
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node):
        """Обработчик по умолчанию"""
        raise Exception(f'No visitor for {type(node).__name__}')

    def visit_global_declaration(self, node):
        """Обрабатывает глобальные объявления переменных и массивов"""
        if isinstance(node, AST.VariableDeclarationNode):
            var_label = f"_var_{node.name}"
            size = self.get_type_size(node.var_type)
            self.global_variables[node.name] = (node.var_type, var_label, size)

            # ИСПРАВЛЕНО: Для структур используем правильный размер
            if node.var_type in self.struct_definitions:
                struct_size = self.struct_definitions[node.var_type]['size']
                self.emit_data(f"{var_label}: times {struct_size} db 0 ; struct {node.var_type}\n")
            else:
                # Для примитивных типов
                if size == 1:
                    self.emit_data(f"{var_label}: db 0\n")
                elif size == 2:
                    self.emit_data(f"{var_label}: dw 0\n")
                else:
                    self.emit_data(f"{var_label}: dd 0\n")

        elif isinstance(node, AST.ArrayDeclarationNode):
            if not isinstance(node.size_node, AST.NumberLiteralNode):
                raise TypeError("Array size must be constant")
            
            array_label = f"_arr_{node.name}"
            element_size = self.get_type_size(node.var_type)
            array_size = node.size_node.value
            
            self.global_variables[node.name] = ("array", array_label, element_size)
            self.array_sizes[node.name] = array_size
            
            # Если есть инициализатор
            if node.initial_value and isinstance(node.initial_value, AST.StringLiteralNode):
                # Инициализация строкой
                string_data = self._extract_string_data(node.initial_value)
                bytes_data = ", ".join(str(ord(char)) for char in string_data)
                # Дополняем нулями до размера массива
                remaining = array_size - len(string_data) - 1  # -1 для нулевого терминатора
                if remaining > 0:
                    self.emit_data(f"{array_label}: db {bytes_data}, 0, times {remaining} db 0\n")
                else:
                    self.emit_data(f"{array_label}: db {bytes_data}, 0\n")
            else:
                # Обычная инициализация нулями
                if element_size == 1:
                    self.emit_data(f"{array_label}: times {array_size} db 0\n")
                elif element_size == 2:
                    self.emit_data(f"{array_label}: times {array_size} dw 0\n")
                else:
                    self.emit_data(f"{array_label}: times {array_size} dd 0\n")

    def _extract_string_data(self, segments):
        """Извлекает строковые данные из сегментов"""
        if isinstance(segments, str):
            return segments
        
        result = ""
        for segment in segments:
            if isinstance(segment, tuple) and len(segment) == 2:
                is_string, data = segment
                if is_string:
                    result += data
                else:
                    result += chr(data)
            elif isinstance(segment, str):
                result += segment
        return result

    def visit_FunctionDeclarationNode(self, node):
        """Генерирует функцию с правильной обработкой локальных переменных"""
        self.current_function = node.name
        self.local_variables.clear()
        
        # Регистрируем параметры
        param_offset = 4 if self.target_bits == 16 else 8
        for param_type, param_name in node.params:
            param_size = 2 if self.target_bits == 16 else 4
            self.local_variables[param_name] = (param_type, param_offset, param_size)
            param_offset += param_size
        
        # Находим локальные объявления и вычисляем их размер
        local_size = 0
        local_declarations = self.find_local_declarations(node.body)
        
        for decl in local_declarations:
            if isinstance(decl, AST.VariableDeclarationNode):
                size = self.get_type_size(decl.var_type)
                local_size += size
                self.local_variables[decl.name] = (decl.var_type, -local_size, size)
            elif isinstance(decl, AST.ArrayDeclarationNode):
                if not isinstance(decl.size_node, AST.NumberLiteralNode):
                    raise TypeError("Local array size must be constant")
                element_size = self.get_type_size(decl.var_type)
                array_size = decl.size_node.value
                total_size = element_size * array_size
                local_size += total_size
                self.local_variables[decl.name] = ("array", -local_size, element_size)
                self.array_sizes[decl.name] = array_size
        
        # Пролог функции
        self.emit(f"{node.name}:\n")
        self.emit(f"    push {self.base_reg}\n")
        self.emit(f"    mov {self.base_reg}, {self.stack_reg}\n")
        if local_size > 0:
            self.emit(f"    sub {self.stack_reg}, {local_size}\n")
        
        # Инициализируем локальные массивы строками
        for decl in local_declarations:
            if isinstance(decl, AST.ArrayDeclarationNode) and decl.initial_value:
                if isinstance(decl.initial_value, AST.StringLiteralNode):
                    self._initialize_local_array_with_string(decl)
        
        # Тело функции
        for stmt in node.body:
            self.visit(stmt)
        
        # Эпилог
        self.emit(f".{node.name}_end:\n")
        self.emit(f"    mov {self.stack_reg}, {self.base_reg}\n")
        self.emit(f"    pop {self.base_reg}\n")
        self.emit("    ret\n\n")
        
        self.current_function = None

    def visit_local_array_initialization(self, array_node):
        """Обрабатывает инициализацию локального массива"""
        if isinstance(array_node.initial_value, AST.StringLiteralNode):
            # Создаем временную строку в секции данных
            temp_label = f"_temp_str_{self.string_counter}"
            self.string_counter += 1
            
            string_data = self._extract_string_data(array_node.initial_value)
            bytes_data = ", ".join(str(ord(char)) for char in string_data)
            self.emit_data(f"{temp_label}: db {bytes_data}, 0\n")
            
            # Генерируем код копирования
            var_info = self.local_variables[array_node.name]
            array_offset = var_info[1]
            array_size = self.array_sizes[array_node.name]
            
            copy_label = self.get_label("strcpy")
            
            self.emit(f"; --- Initialize array '{array_node.name}' from {temp_label} ---\n")
            self.emit(f"    mov si, {self.base_reg}\n")
            self.emit(f"    sub si, {-array_offset}\n")
            self.emit(f"    mov di, {temp_label}\n")
            self.emit(f"    mov cx, {min(len(string_data) + 1, array_size)}\n")
            self.emit(f"{copy_label}:\n")
            self.emit(f"    mov al, [di]\n")
            self.emit(f"    mov [si], al\n")
            self.emit(f"    inc si\n")
            self.emit(f"    inc di\n")
            self.emit(f"    dec cx\n")
            self.emit(f"    jnz {copy_label}\n")

    def visit_VariableReferenceNode(self, node):
        """Загружает значение переменной с использованием компактного NASM синтаксиса"""
        if node.name in self.local_variables:
            var_type, offset, size = self.local_variables[node.name]
            
            if var_type == "array":
                # Для массивов возвращаем адрес
                if offset > 0:
                    self.emit(f"    lea {self.main_reg}, [{self.base_reg}+{offset}]\n")
                else:
                    self.emit(f"    lea {self.main_reg}, [{self.base_reg}{offset}]\n")
            else:
                # Для переменных загружаем значение
                if size == 1:
                    self.emit(f"    xor {self.main_reg}, {self.main_reg}\n")
                    if offset > 0:
                        self.emit(f"    mov al, [{self.base_reg}+{offset}]\n")
                    else:
                        self.emit(f"    mov al, [{self.base_reg}{offset}]\n")
                elif size == 2:
                    if offset > 0:
                        self.emit(f"    mov {self.main_reg}, [{self.base_reg}+{offset}]\n")
                    else:
                        self.emit(f"    mov {self.main_reg}, [{self.base_reg}{offset}]\n")
                else:
                    if self.target_bits == 16:
                        if offset > 0:
                            self.emit(f"    mov {self.main_reg}, [{self.base_reg}+{offset}]\n")
                        else:
                            self.emit(f"    mov {self.main_reg}, [{self.base_reg}{offset}]\n")
                    else:
                        if offset > 0:
                            self.emit(f"    mov {self.main_reg}, dword [{self.base_reg}+{offset}]\n")
                        else:
                            self.emit(f"    mov {self.main_reg}, dword [{self.base_reg}{offset}]\n")
                    
        elif node.name in self.global_variables:
            var_type, label, size = self.global_variables[node.name]
            
            if var_type == "array":
                self.emit(f"    mov {self.main_reg}, {label}\n")
            else:
                if size == 1:
                    self.emit(f"    xor {self.main_reg}, {self.main_reg}\n")
                    self.emit(f"    mov al, [{label}]\n")
                else:
                    self.emit(f"    mov {self.main_reg}, [{label}]\n")
        else:
            raise NameError(f"Variable '{node.name}' not defined")

    def visit_ArrayAccessNode(self, node):
        """Обрабатывает доступ к элементу массива с компактным синтаксисом"""
        # Вычисляем индекс
        self.visit(node.index_node)
        self.emit(f"    push {self.main_reg} ; Save index\n")
        
        # Получаем информацию о массиве
        if node.name in self.local_variables:
            var_type, offset, element_size = self.local_variables[node.name]
            # Используем LEA для получения эффективного адреса
            if offset > 0:
                self.emit(f"    lea {self.temp_reg}, [{self.base_reg}+{offset}]\n")
            else:
                self.emit(f"    lea {self.temp_reg}, [{self.base_reg}{offset}]\n")
        elif node.name in self.global_variables:
            var_type, label, element_size = self.global_variables[node.name]
            self.emit(f"    mov {self.temp_reg}, {label}\n")
        else:
            raise NameError(f"Array '{node.name}' not defined")
        
        # Вычисляем окончательный адрес
        self.emit(f"    pop {self.main_reg} ; Restore index\n")
        
        if element_size > 1:
            if element_size == 2:
                self.emit(f"    shl {self.main_reg}, 1 ; Multiply by 2\n")
            elif element_size == 4:
                self.emit(f"    shl {self.main_reg}, 2 ; Multiply by 4\n")
            else:
                self.emit(f"    imul {self.main_reg}, {element_size}\n")
        
        # Загружаем значение используя масштабированную индексацию
        if element_size == 1:
            self.emit(f"    xor {self.main_reg}, {self.main_reg}\n")
            self.emit(f"    mov al, [{self.temp_reg}+{self.main_reg}]\n")
        elif element_size == 2:
            if self.target_bits == 16:
                self.emit(f"    mov {self.main_reg}, word [{self.temp_reg}+{self.main_reg}]\n")
            else:
                self.emit(f"    xor {self.main_reg}, {self.main_reg}\n")
                self.emit(f"    mov ax, word [{self.temp_reg}+{self.main_reg}]\n")
        else:
            size_prefix = 'word' if self.target_bits == 16 else 'dword'
            self.emit(f"    mov {self.main_reg}, {size_prefix} [{self.temp_reg}+{self.main_reg}]\n")

    def visit_ArrayDeclarationNode(self, node):
        """Обрабатывает объявление массивов в NASM"""
        if not isinstance(node.size_node, AST.NumberLiteralNode):
            raise TypeError("Array size must be constant")

        array_size = node.size_node.value
        element_size = self.get_type_size(node.var_type)
        total_size = array_size * element_size

        self.array_sizes[node.name] = array_size

        if self.current_function is None:
            # Глобальный массив (код остается без изменений)
            array_label = f"_arr_{node.name}"
            self.global_variables[node.name] = ("array", array_label, element_size)
            
            if node.initial_value and isinstance(node.initial_value, AST.StringLiteralNode):
                string_data = self._extract_string_data(node.initial_value.segments)
                bytes_data = ", ".join(str(ord(char)) for char in string_data)
                remaining = array_size - len(string_data) - 1
                if remaining > 0:
                    self.emit_data(f"{array_label}: db {bytes_data}, 0, times {remaining} db 0\n")
                else:
                    self.emit_data(f"{array_label}: db {bytes_data}, 0\n")
            else:
                if element_size == 1:
                    self.emit_data(f"{array_label}: times {array_size} db 0\n")
                elif element_size == 2:
                    self.emit_data(f"{array_label}: times {array_size} dw 0\n")
                else:
                    self.emit_data(f"{array_label}: times {array_size} dd 0\n")
        else:
            # УДАЛЕНО: Дублирующий вызов _initialize_local_array_with_string
            # Локальный массив уже инициализируется в visit_FunctionDeclarationNode
            pass
                
    def _initialize_local_array_with_string(self, array_node):
        """Улучшенная инициализация локального массива строкой"""
        string_data = self._extract_string_data(array_node.initial_value.segments)
        var_info = self.local_variables[array_node.name]
        array_offset = var_info[1]
        array_size = self.array_sizes[array_node.name]

        # Создаем строку в секции данных
        init_label = f"_var_str_init_{self.string_counter}"
        self.string_counter += 1
        
        bytes_data = ", ".join(str(ord(char)) for char in string_data)
        self.emit_data(f"{init_label}: db {bytes_data}, 0\n")

        # Эффективное копирование с помощью строковых инструкций
        self.emit(f"; --- Initialize array '{array_node.name}' from {init_label} ---\n")
        
        # Адрес назначения в DI
        if array_offset > 0:
            self.emit(f" lea di, [{self.base_reg}+{array_offset}]\n")
        else:
            self.emit(f" lea di, [{self.base_reg}{array_offset}]\n")
        
        # Адрес источника в SI
        self.emit(f" mov si, {init_label}\n")
        
        # Количество байт для копирования
        copy_length = min(len(string_data) + 1, array_size)  # +1 для нулевого терминатора
        self.emit(f" mov cx, {copy_length}\n")
        
        # Копирование строки
        self.emit(" cld ; Clear direction flag\n")
        self.emit(" rep movsb ; Copy string\n")

    def visit_AddressOfNode(self, node):
        """Обрабатывает взятие адреса с использованием LEA"""
        if isinstance(node.node_to_address, AST.VariableReferenceNode):
            var_name = node.node_to_address.name
            
            if var_name in self.local_variables:
                var_type, offset, size = self.local_variables[var_name]
                if offset > 0:
                    self.emit(f"    lea {self.main_reg}, [{self.base_reg}+{offset}]\n")
                else:
                    self.emit(f"    lea {self.main_reg}, [{self.base_reg}{offset}]\n")
                    
            elif var_name in self.global_variables:
                var_type, label, size = self.global_variables[var_name]
                self.emit(f"    mov {self.main_reg}, {label}\n")
            else:
                raise NameError(f"Variable '{var_name}' not defined")
                
        elif isinstance(node.node_to_address, AST.ArrayAccessNode):
            # Адрес элемента массива
            array_node = node.node_to_address
            
            # Вычисляем индекс
            self.visit(array_node.index_node)
            self.emit(f"    push {self.main_reg} ; Save index\n")
            
            # Получаем базовый адрес массива
            if array_node.name in self.local_variables:
                var_type, offset, element_size = self.local_variables[array_node.name]
                self.emit(f"    mov {self.temp_reg}, {self.base_reg}\n")
                if offset > 0:
                    self.emit(f"    add {self.temp_reg}, {offset}\n")
                else:
                    self.emit(f"    sub {self.temp_reg}, {-offset}\n")
            elif array_node.name in self.global_variables:
                var_type, label, element_size = self.global_variables[array_node.name]
                self.emit(f"    mov {self.temp_reg}, {label}\n")
            
            # Вычисляем адрес элемента
            self.emit(f"    pop {self.main_reg} ; Restore index\n")
            if element_size > 1:
                if element_size == 2:
                    self.emit(f"    shl {self.main_reg}, 1\n")
                elif element_size == 4:
                    self.emit(f"    shl {self.main_reg}, 2\n")
                else:
                    self.emit(f"    mov {'cx' if self.target_bits == 16 else 'ecx'}, {element_size}\n")
                    self.emit(f"    imul {self.main_reg}, {'cx' if self.target_bits == 16 else 'ecx'}\n")
            
            self.emit(f"    add {self.main_reg}, {self.temp_reg} ; Address of element\n")
        else:
            raise NotImplementedError("Address-of operator not implemented for this node type")

    def visit_DereferenceNode(self, node):
        """Обрабатывает разыменование указателя (@ptr)"""
        # Вычисляем адрес
        self.visit(node.pointer_node)
        
        # Загружаем значение по адресу (предполагаем указатель на слово)
        self.emit(f"    mov {self.temp_reg}, {self.main_reg}\n")
        if self.target_bits == 16:
            self.emit(f"    mov {self.main_reg}, [{self.temp_reg}]\n")
        else:
            self.emit(f"    mov {self.main_reg}, dword [{self.temp_reg}]\n")

    def visit_AssignmentNode(self, node):
        """Генерирует присваивание с компактным NASM синтаксисом"""
        # Вычисляем правую часть
        self.visit(node.expression)

        # Присваиваем переменной
        if isinstance(node.variable, AST.VariableReferenceNode):
            # Существующий код для обычных переменных остается без изменений
            var_name = node.variable.name
            if var_name in self.local_variables:
                var_type, offset, size = self.local_variables[var_name]
                if size == 1:
                    if offset > 0:
                        self.emit(f" mov [{self.base_reg}+{offset}], al\n")
                    else:
                        self.emit(f" mov [{self.base_reg}{offset}], al\n")
                elif size == 2:
                    if offset > 0:
                        self.emit(f" mov [{self.base_reg}+{offset}], {self.main_reg if self.target_bits == 16 else 'ax'}\n")
                    else:
                        self.emit(f" mov [{self.base_reg}{offset}], {self.main_reg if self.target_bits == 16 else 'ax'}\n")
                else:
                    if self.target_bits == 16:
                        if offset > 0:
                            self.emit(f" mov [{self.base_reg}+{offset}], {self.main_reg}\n")
                        else:
                            self.emit(f" mov [{self.base_reg}{offset}], {self.main_reg}\n")
                    else:
                        if offset > 0:
                            self.emit(f" mov dword [{self.base_reg}+{offset}], {self.main_reg}\n")
                        else:
                            self.emit(f" mov dword [{self.base_reg}{offset}], {self.main_reg}\n")
            elif var_name in self.global_variables:
                var_type, label, size = self.global_variables[var_name]
                if size == 1:
                    self.emit(f" mov [{label}], al\n")
                elif size == 2:
                    self.emit(f" mov [{label}], {'ax' if self.target_bits == 16 else 'ax'}\n")
                else:
                    self.emit(f" mov [{label}], {self.main_reg}\n")
            else:
                raise NameError(f"Variable '{var_name}' not defined")

        # НОВОЕ: Обработка присваивания полю структуры
        elif isinstance(node.variable, AST.PropertyAccessNode):
            self._assign_to_struct_field(node.variable, self.main_reg)

        elif isinstance(node.variable, AST.ArrayAccessNode):
            # Существующий код для массивов остается без изменений
            self.emit(f" push {self.main_reg} ; Save value\n")
            
            array_name = node.variable.name
            self.visit(node.variable.index_node)
            self.emit(f" push {self.main_reg} ; Save index\n")

            if array_name in self.local_variables:
                var_type, offset, element_size = self.local_variables[array_name]
                if offset > 0:
                    self.emit(f" lea {self.temp_reg}, [{self.base_reg}+{offset}]\n")
                else:
                    self.emit(f" lea {self.temp_reg}, [{self.base_reg}{offset}]\n")
            elif array_name in self.global_variables:
                var_type, label, element_size = self.global_variables[array_name]
                self.emit(f" mov {self.temp_reg}, {label}\n")

            self.emit(f" pop {self.main_reg} ; Restore index\n")
            if element_size > 1:
                if element_size == 2:
                    self.emit(f" shl {self.main_reg}, 1\n")
                elif element_size == 4:
                    self.emit(f" shl {self.main_reg}, 2\n")
                else:
                    self.emit(f" imul {self.main_reg}, {element_size}\n")

            self.emit(f" add {self.temp_reg}, {self.main_reg} ; Element address\n")
            self.emit(f" pop {self.main_reg} ; Restore value\n")
            
            if element_size == 1:
                self.emit(f" mov [{self.temp_reg}], al\n")
            elif element_size == 2:
                self.emit(f" mov word [{self.temp_reg}], {'ax' if self.target_bits == 16 else 'ax'}\n")
            else:
                size_prefix = 'word' if self.target_bits == 16 else 'dword'
                self.emit(f" mov {size_prefix} [{self.temp_reg}], {self.main_reg}\n")
            
        elif isinstance(node.variable, AST.StructArrayAccessNode):
            # Присваивание элементу массива поля структуры
            self.emit(f" push {self.main_reg} ; Save value\n")
            self._assign_to_struct_array_element(node.variable)
            
    def _assign_to_struct_array_element(self, struct_array_node):
        """Присваивает значение элементу массива поля структуры"""
        # Вычисляем индекс
        self.visit(struct_array_node.index_node)
        self.emit(f" push {self.main_reg} ; Save index\n")
        
        # Получаем информацию о структуре
        struct_info = self.get_var_info(struct_array_node.struct_name)
        if not struct_info:
            raise NameError(f"Struct variable '{struct_array_node.struct_name}' not defined")
        
        struct_type, struct_location, _ = struct_info
        
        if struct_type not in self.struct_definitions:
            raise TypeError(f"Variable '{struct_array_node.struct_name}' is not a struct")
        
        struct_def = self.struct_definitions[struct_type]
        if struct_array_node.field_name not in struct_def['fields']:
            raise NameError(f"Struct '{struct_type}' has no field '{struct_array_node.field_name}'")
        
        field_info = struct_def['fields'][struct_array_node.field_name]
        field_offset = field_info['offset']
        
        # Проверяем, что поле действительно является массивом
        if 'array_size' not in field_info:
            raise TypeError(f"Field '{struct_array_node.field_name}' is not an array")
        
        # Получаем базовый адрес поля массива
        if isinstance(struct_location, int):  # Локальная структура
            total_offset = struct_location + field_offset
            if total_offset > 0:
                self.emit(f" lea {self.temp_reg}, [{self.base_reg}+{total_offset}]\n")
            else:
                self.emit(f" lea {self.temp_reg}, [{self.base_reg}{total_offset}]\n")
        else:  # Глобальная структура
            if field_offset > 0:
                self.emit(f" lea {self.temp_reg}, [{struct_location}+{field_offset}]\n")
            else:
                self.emit(f" mov {self.temp_reg}, {struct_location}\n")
        
        # Добавляем индекс к базовому адресу
        self.emit(f" pop {self.main_reg} ; Restore index\n")
        
        # Для массивов символов индекс = смещение в байтах
        element_type = field_info.get('element_type', 'char')
        element_size = self.get_type_size(element_type)
        
        if element_size > 1:
            if element_size == 2:
                self.emit(f" shl {self.main_reg}, 1 ; Multiply index by 2\n")
            elif element_size == 4:
                self.emit(f" shl {self.main_reg}, 2 ; Multiply index by 4\n")
            else:
                self.emit(f" imul {self.main_reg}, {element_size}\n")
        
        self.emit(f" add {self.temp_reg}, {self.main_reg} ; Calculate element address\n")
        
        # Восстанавливаем значение и сохраняем
        self.emit(f" pop {self.main_reg} ; Restore value\n")
        
        # Сохраняем значение в элемент массива
        if element_size == 1:
            self.emit(f" mov [{self.temp_reg}], al\n")
        elif element_size == 2:
            self.emit(f" mov word [{self.temp_reg}], {'ax' if self.target_bits == 16 else 'ax'}\n")
        else:
            size_prefix = 'word' if self.target_bits == 16 else 'dword'
            self.emit(f" mov {size_prefix} [{self.temp_reg}], {self.main_reg}\n")
                
    def _assign_to_struct_field(self, property_node, value_reg):
        """Присваивание значения полю структуры (включая через указатели и массивы)"""
        var_name = property_node.variable_name
        field_name = property_node.property_name
        
        var_info = self.get_var_info(var_name)
        if not var_info:
            raise NameError(f"Variable '{var_name}' not defined")
        
        var_type, location, _ = var_info
        
        # НОВОЕ: Проверяем, является ли это указателем на структуру
        is_pointer_to_struct = False
        struct_type_name = var_type
        
        if var_type.endswith('*'):
            struct_type_name = var_type[:-1]
            is_pointer_to_struct = True
        
        if struct_type_name not in self.struct_definitions:
            raise TypeError(f"Variable '{var_name}' is not a struct or pointer to struct")
        
        struct_def = self.struct_definitions[struct_type_name]
        if field_name not in struct_def['fields']:
            raise NameError(f"Struct '{struct_type_name}' has no field '{field_name}'")
        
        field_info = struct_def['fields'][field_name]
        field_offset = field_info['offset']
        field_size = field_info['size']
        
        if is_pointer_to_struct:
            # НОВОЕ: Присваивание через указатель
            # 1. Загружаем адрес структуры из указателя
            if isinstance(location, int):  # Локальная переменная-указатель
                if location > 0:
                    self.emit(f" mov {self.temp_reg}, [{self.base_reg}+{location}]\n")
                else:
                    self.emit(f" mov {self.temp_reg}, [{self.base_reg}{location}]\n")
            else:  # Глобальная переменная-указатель
                self.emit(f" mov {self.temp_reg}, [{location}]\n")
            
            # 2. Добавляем смещение поля
            if field_offset > 0:
                self.emit(f" add {self.temp_reg}, {field_offset}\n")
            
            # 3. Проверяем, является ли поле массивом
            if 'array_size' in field_info:
                # Для массивов копируем строку
                self.emit(f" mov di, {self.temp_reg}\n")
                self.emit(f" mov si, {value_reg}\n")
                array_size = field_info['array_size']
                self.emit(f" mov cx, {array_size}\n")
                self.emit(" cld\n")
                self.emit(" rep movsb\n")
            else:
                # Для обычных полей сохраняем значение
                if field_size == 1:
                    self.emit(f" mov [{self.temp_reg}], al\n")
                elif field_size == 2:
                    self.emit(f" mov word [{self.temp_reg}], {value_reg}\n")
                else:
                    size_prefix = 'word' if self.target_bits == 16 else 'dword'
                    self.emit(f" mov {size_prefix} [{self.temp_reg}], {value_reg}\n")
        else:
            # Прямой доступ к структурам (существующая логика)
            # ИСПРАВЛЕНО: Для массивов используем простое копирование как для обычных массивов
            if 'array_size' in field_info:
                # Вычисляем адрес поля массива
                if isinstance(location, int):  # Локальная структура
                    total_offset = location + field_offset
                    if total_offset > 0:
                        self.emit(f" lea di, [{self.base_reg}+{total_offset}]\n")
                    else:
                        self.emit(f" lea di, [{self.base_reg}{total_offset}]\n")
                else:  # Глобальная структура
                    if field_offset > 0:
                        self.emit(f" lea di, [{location}+{field_offset}]\n")
                    else:
                        self.emit(f" mov di, {location}\n")
                
                # Адрес источника уже в main_reg (строка)
                self.emit(f" mov si, {self.main_reg}\n")
                
                # Простое копирование как для обычных массивов
                array_size = field_info['array_size']
                self.emit(f" mov cx, {array_size}\n")
                self.emit(" cld\n")
                self.emit(" rep movsb\n")
                return
            
            # Обычное поле - сохраняем значение
            if isinstance(location, int):
                total_offset = location + field_offset
                if total_offset > 0:
                    addr = f"[{self.base_reg}+{total_offset}]"
                else:
                    addr = f"[{self.base_reg}{total_offset}]"
            else:
                if field_offset > 0:
                    addr = f"[{location}+{field_offset}]"
                else:
                    addr = f"[{location}]"
            
            if field_size == 1:
                self.emit(f" mov {addr}, al\n")
            elif field_size == 2:
                self.emit(f" mov word {addr}, {value_reg}\n")
            else:
                size_prefix = 'word' if self.target_bits == 16 else 'dword'
                self.emit(f" mov {size_prefix} {addr}, {value_reg}\n")
            
    def _initialize_struct_array_field_with_string(self, struct_name, field_name, struct_location, field_offset, field_info):
        """Инициализирует массив-поле структуры строкой"""
        # Получаем строку из последнего вычисленного значения (должно быть в строковом литерале)
        # Для простоты создаем временную строку
        temp_label = f"_temp_struct_str_{self.string_counter}"
        self.string_counter += 1
        
        # Адрес поля массива
        if isinstance(struct_location, int):  # Локальная структура
            total_offset = struct_location + field_offset
            if total_offset > 0:
                self.emit(f" lea di, [{self.base_reg}+{total_offset}]\n")
            else:
                self.emit(f" lea di, [{self.base_reg}{total_offset}]\n")
        else:  # Глобальная структура
            if field_offset > 0:
                self.emit(f" lea di, [{struct_location}+{field_offset}]\n")
            else:
                self.emit(f" mov di, {struct_location}\n")
        
        # Источник - строка уже в ax, это адрес строки
        self.emit(f" mov si, {self.main_reg} ; String address from previous computation\n")
        
        # Копируем строку
        array_size = field_info.get('array_size', field_info['size'])
        self.emit(f" mov cx, {array_size}\n")
        self.emit(" cld\n")
        
        copy_loop = self.get_label("struct_strcpy")
        copy_end = self.get_label("struct_strcpy_end")
        
        self.emit(f"{copy_loop}:\n")
        self.emit(" lodsb ; Load from [si] to al, increment si\n")
        self.emit(" stosb ; Store al to [di], increment di\n")
        self.emit(" test al, al ; Check for null terminator\n")
        self.emit(f" je {copy_end}\n")
        self.emit(" loop " + copy_loop + "\n")
        self.emit(f"{copy_end}:\n")
    
    def visit_NumberLiteralNode(self, node):
        """Загружает числовой литерал"""
        self.emit(f"    mov {self.main_reg}, {node.value}\n")

    def visit_StringLiteralNode(self, node):
        """Создаёт строковый литерал и возвращает его адрес"""
        label = f"_str_{self.string_counter}"
        self.string_counter += 1

        # ИСПРАВЛЕНО: Передаем node.segments вместо node
        string_data = self._extract_string_data(node.segments)
        bytes_data = ", ".join(str(ord(char)) for char in string_data)

        # Генерируем данные
        self.emit_data(f"{label}: db {bytes_data}, 0\n")

        # Загружаем адрес строки
        self.emit(f" mov {self.main_reg}, {label}\n")

    def visit_BinaryOperationNode(self, node):
        """Расширенная поддержка всех операций"""
        # Вычисляем правый операнд
        self.visit(node.right)
        self.emit(f" push {self.main_reg}\n")

        # Вычисляем левый операнд  
        self.visit(node.left)
        self.emit(f" pop {self.temp_reg}\n")

        # Выполняем операцию
        if node.operator == '+':
            self.emit(f" add {self.main_reg}, {self.temp_reg}\n")
        elif node.operator == '-':
            self.emit(f" sub {self.main_reg}, {self.temp_reg}\n")
        elif node.operator == '*':
            self.emit(f" imul {self.main_reg}, {self.temp_reg}\n")
        elif node.operator in ('/', '//'):
            if self.target_bits == 16:
                self.emit(f" xor dx, dx\n")
                self.emit(f" idiv {self.temp_reg}\n")
            else:
                self.emit(f" xor edx, edx\n")
                self.emit(f" idiv {self.temp_reg}\n")
        
        # НОВОЕ: Побитовые операции
        elif node.operator == '<<':
            self.emit(f" mov {'cl' if self.target_bits == 16 else 'ecx'}, {self.temp_reg}\n")
            self.emit(f" shl {self.main_reg}, cl\n")
        elif node.operator == '>>':
            self.emit(f" mov {'cl' if self.target_bits == 16 else 'ecx'}, {self.temp_reg}\n")
            self.emit(f" shr {self.main_reg}, cl\n")
        elif node.operator == '&':
            self.emit(f" and {self.main_reg}, {self.temp_reg}\n")
        elif node.operator == '|':
            self.emit(f" or {self.main_reg}, {self.temp_reg}\n")
        elif node.operator == '^':
            self.emit(f" xor {self.main_reg}, {self.temp_reg}\n")
        elif node.operator == '%':
            # Остаток от деления
            if self.target_bits == 16:
                self.emit(f" xor dx, dx\n")
                self.emit(f" idiv {self.temp_reg}\n")
                self.emit(f" mov {self.main_reg}, dx ; Remainder\n")
            else:
                self.emit(f" xor edx, edx\n")
                self.emit(f" idiv {self.temp_reg}\n")
                self.emit(f" mov {self.main_reg}, edx ; Remainder\n")
        else:
            raise NotImplementedError(f"Operator {node.operator} not implemented")

    def visit_FunctionCallNode(self, node):
        """Генерирует вызов функции"""
        # Помещаем аргументы на стек (в обратном порядке)
        for arg in reversed(node.args):
            self.visit(arg)
            self.emit(f"    push {self.main_reg}\n")
        
        # Вызов функции
        self.emit(f"    call {node.name}\n")
        
        # Очистка стека
        if node.args:
            stack_size = len(node.args) * (2 if self.target_bits == 16 else 4)
            self.emit(f"    add {self.stack_reg}, {stack_size}\n")

    def visit_ReturnNode(self, node):
        """Генерирует return"""
        if node.value_node:
            self.visit(node.value_node)
        self.emit(f"    jmp .{self.current_function}_end\n")

    def visit_WhileNode(self, node):
        """Генерирует цикл while"""
        start_label = self.get_label(".L_while_start")
        end_label = self.get_label(".L_while_end")
        
        self.emit(f"{start_label}:\n")
        self.visit(node.condition)
        self.emit(f"    cmp {self.main_reg}, 0\n")
        self.emit(f"    je {end_label}\n")
        
        for stmt in node.body:
            self.visit(stmt)
        
        self.emit(f"    jmp {start_label}\n")
        self.emit(f"{end_label}:\n")

    def get_type_size(self, type_name):
        """Возвращает размер типа для нужной архитектуры"""
        # ИСПРАВЛЕНО: Сначала проверяем, не является ли это структурой
        if type_name in self.struct_definitions:
            return self.struct_definitions[type_name]['size']
        
        # Проверяем, не является ли это массивом структуры (например "Inst[10]")
        if '[' in type_name:
            base_type = type_name.split('[')[0]
            if base_type in self.struct_definitions:
                return self.struct_definitions[base_type]['size']
        
        if self.target_bits == 16:
            sizes = {
                'char': 1, 'num16': 2, 'num32': 4, 'float': 4,
                'char*': 2, 'num16*': 2, 'num32*': 2
            }
        else:
            sizes = {
                'char': 1, 'num16': 2, 'num32': 4, 'float': 4,
                'char*': 4, 'num16*': 4, 'num32*': 4
            }
        
        return sizes.get(type_name, 2 if self.target_bits == 16 else 4)

    def find_local_declarations(self, statements):
        """Рекурсивно находит все локальные объявления"""
        declarations = []
        for stmt in statements:
            if isinstance(stmt, (AST.VariableDeclarationNode, AST.ArrayDeclarationNode)):
                declarations.append(stmt)
            # Можно добавить рекурсивный поиск в if/while блоках
            if hasattr(stmt, 'body'):
                declarations.extend(self.find_local_declarations(stmt.body))
        return declarations

    def visit_NasmNode(self, node):
        """Обрабатывает многострочный nasm код"""
        self.emit("; === NASM inline assembly start ===\n")
        
        for part in node.assembly_parts:
            if isinstance(part, list):
                # Обрабатываем сегменты строки
                assembly_line = self._extract_string_data(part)
            else:
                assembly_line = part
            
            self.emit(f"    {assembly_line}\n")
        
        self.emit("; === NASM inline assembly end ===\n")
        
    def visit_NasmfNode(self, node):
        """Обрабатывает nasmf inline assembly (версии 1 и 2)"""
        # Определяем версию по наличию constraints
        if hasattr(node, 'output_constraints') and node.output_constraints:
            return self._visit_nasmf_v2(node)
        else:
            return self._visit_nasmf_v1(node)

    def _visit_nasmf_v1(self, node):
        """Упрощённая версия для 16-битного режима"""
        template = ""
        for part in node.assembly_parts:
            if isinstance(part, list):
                template += self._extract_string_data(part)
            else:
                template += part
            template += "\n"

        if node.args:
            # Сохраняем аргументы на стеке
            for i, arg in enumerate(node.args):
                self.visit(arg)
                self.emit(f" push {self.main_reg} ; Save nasmf arg {i} on stack\n")

            # Загружаем аргументы в регистры с помощью POP (в обратном порядке)
            available_regs = ['ax', 'bx', 'cx', 'dx']
            substitutions = {}
            
            # Извлекаем аргументы в обратном порядке (последний сохранённый первым)
            for i in range(min(len(node.args), len(available_regs))):
                reg = available_regs[len(node.args) - 1 - i]
                self.emit(f" pop {reg} ; Load nasmf arg {len(node.args) - 1 - i}\n")
                substitutions[len(node.args) - 1 - i] = reg

            # Подставляем аргументы
            for i, replacement in substitutions.items():
                template = template.replace(f"{{{i}}}", replacement)

            self.emit("; === NASMF v1 inline assembly start ===\n")
            self.emit(template)
            self.emit("; === NASMF v1 inline assembly end ===\n")
        else:
            self.emit("; === NASMF v1 inline assembly start ===\n")
            self.emit(template)
            self.emit("; === NASMF v1 inline assembly end ===\n")

    def _visit_nasmf_v2(self, node):
        """Обрабатывает новую версию nasmf с constraints в стиле GCC"""
        template = ""
        for part in node.assembly_parts:
            if isinstance(part, list):
                template += self._extract_string_data(part)
            else:
                template += part
            template += "\n"
        
        self.emit("; === NASMF v2 inline assembly start ===\n")
        
        # 1. Сохраняем clobbered регистры
        saved_regs = []
        for reg_item in node.clobber_list:
            # Проверяем, является ли reg_item списком или строкой
            if isinstance(reg_item, list):
                reg = self._extract_string_data(reg_item)
            else:
                reg = reg_item
                
            if reg != "memory":
                nasm_reg = self._convert_register_name(reg)
                if nasm_reg:
                    self.emit(f"    push {nasm_reg} ; Save clobbered register\n")
                    saved_regs.append(nasm_reg)
        
        # 2. Обрабатываем input constraints
        input_reg_map = {}
        for i, (constraint_str, variable_expr) in enumerate(node.input_constraints):
            # Обрабатываем constraint_str если это список
            if isinstance(constraint_str, list):
                constraint_str = self._extract_string_data(constraint_str)
                
            if constraint_str.lstrip('=').startswith('r'):  # register constraint
                self.visit(variable_expr)
                reg = self._allocate_register()  # Теперь без аргументов
                if reg != self.main_reg:
                    self.emit(f"    mov {reg}, {self.main_reg} ; Load input {i}\n")
                input_reg_map[i] = reg
        
        # 3. Подставляем input constraints в шаблон
        for i, reg in input_reg_map.items():
            template = template.replace(f"{{{i}}}", reg)
        
        # 4. Вставляем основной asm код
        self.emit(template)
        
        # 5. Обрабатываем output constraints
        for i, (constraint_str, variable_expr) in enumerate(node.output_constraints):
            if isinstance(constraint_str, list):
                constraint_str = self._extract_string_data(constraint_str)
                
            if constraint_str.startswith('=r'):
                reg = self._allocate_register()  # Без аргументов
                if isinstance(variable_expr, AST.VariableReferenceNode):
                    self._store_to_variable(reg, variable_expr.name)
        
        # 6. Восстанавливаем сохраненные регистры
        for reg in reversed(saved_regs):
            self.emit(f"    pop {reg} ; Restore clobbered register\n")
        
        self.emit("; === NASMF v2 inline assembly end ===\n")

    def _convert_register_name(self, reg_name):
        """Конвертирует имя регистра в NASM формат"""
        reg_map = {
            'eax': 'ax' if self.target_bits == 16 else 'eax',
            'ebx': 'bx' if self.target_bits == 16 else 'ebx',
            'ecx': 'cx' if self.target_bits == 16 else 'ecx',
            'edx': 'dx' if self.target_bits == 16 else 'edx',
            'esi': 'si' if self.target_bits == 16 else 'esi',
            'egi': 'di' if self.target_bits == 16 else 'edi',
            'esp': 'sp' if self.target_bits == 16 else 'esp',
            'ebp': 'bp' if self.target_bits == 16 else 'ebp'
        }
        return reg_map.get(reg_name, reg_name)


    def _parse_constraint(self, constraint_str):
        """Парсит строку constraint и возвращает информацию о типе"""
        constraint_info = {
            'is_output': constraint_str.startswith('='),
            'type': 'register',
            'modifier': None
        }
        
        clean_constraint = constraint_str.lstrip('=')
        
        if 'r' in clean_constraint:
            constraint_info['type'] = 'register'
        elif 'm' in clean_constraint:
            constraint_info['type'] = 'memory'
        elif 'i' in clean_constraint:
            constraint_info['type'] = 'immediate'
        
        return constraint_info

    def _allocate_register(self):
        """Выделяет регистр для constraints (упрощенная версия)"""
        # Простая стратегия - всегда используем основной регистр
        return self.main_reg

    def _store_to_variable(self, reg, var_name):
        """Сохраняет значение из регистра в переменную"""
        if var_name in self.local_variables:
            var_type, offset, size = self.local_variables[var_name]
            if offset > 0:
                if size == 1:
                    self.emit(f"    mov [{self.base_reg}+{offset}], al\n")
                else:
                    self.emit(f"    mov [{self.base_reg}+{offset}], {reg}\n")
            else:
                if size == 1:
                    self.emit(f"    mov [{self.base_reg}{offset}], al\n")
                else:
                    self.emit(f"    mov [{self.base_reg}{offset}], {reg}\n")
        elif var_name in self.global_variables:
            var_type, label, size = self.global_variables[var_name]
            if size == 1:
                self.emit(f"    mov [{label}], al\n")
            else:
                self.emit(f"    mov [{label}], {reg}\n")

    def _get_word_reg(self, reg):
        """Возвращает 16-битную версию регистра"""
        word_map = {'eax': 'ax', 'ebx': 'bx', 'ecx': 'cx', 'edx': 'dx'}
        return word_map.get(reg, reg)
    
    def _reassemble_string_from_segments(self, segments):
        """Собирает простую строку из сегментов, превращая байты в символы."""
        # Если нам пришла обычная строка, просто возвращаем ее
        if isinstance(segments, str):
            return segments

        # Если это список строк, объединяем их
        if isinstance(segments, list) and all(isinstance(seg, str) for seg in segments):
            return "".join(segments)

        # Если это список кортежей (is_string, data), обрабатываем как раньше
        if isinstance(segments, list):
            result_string = ""
            for item in segments:
                if isinstance(item, tuple) and len(item) == 2:
                    is_string, data = item
                    if is_string:
                        result_string += data
                    else:
                        try:
                            result_string += chr(data)
                        except ValueError:
                            result_string += '?'
                else:
                    # Если это не кортеж, просто добавляем как строку
                    result_string += str(item)
            return result_string

        # В остальных случаях просто возвращаем строковое представление
        return str(segments)
    
    def get_var_info(self, var_name):
        """Получает информацию о переменной (локальной или глобальной)"""
        if var_name in self.local_variables:
            return self.local_variables[var_name]
        elif var_name in self.global_variables:
            return self.global_variables[var_name]
        else:
            return None
    
    def visit_VariableDeclarationNode(self, node):
        """Обрабатывает объявление переменных в NASM (включая структуры)"""
        element_size = self.get_type_size(node.var_type)

        if self.current_function is None:
            # Глобальная переменная
            var_label = f"_var_{node.name}"
            self.global_variables[node.name] = (node.var_type, var_label, element_size)

            # ИСПРАВЛЕНО: Для структур используем правильный размер
            if node.var_type in self.struct_definitions:
                struct_size = self.struct_definitions[node.var_type]['size']
                self.emit_data(f"{var_label}: times {struct_size} db 0 ; struct {node.var_type}\n")
            else:
                # Для примитивных типов
                if element_size == 1:
                    self.emit_data(f"{var_label}: db 0\n")
                elif element_size == 2:
                    self.emit_data(f"{var_label}: dw 0\n")
                else:
                    self.emit_data(f"{var_label}: dd 0\n")
        else:
            # Локальная переменная уже зарегистрирована в visit_FunctionDeclarationNode
            pass

        # Обработка начального значения остается без изменений
        if node.initial_value:
            self.visit(node.initial_value)
            var_name = node.name
            if var_name in self.local_variables:
                var_type, offset, size = self.local_variables[var_name]
                if offset > 0:
                    if size == 1:
                        self.emit(f" mov [{self.base_reg}+{offset}], al\n")
                    else:
                        self.emit(f" mov [{self.base_reg}+{offset}], {self.main_reg}\n")
                else:
                    if size == 1:
                        self.emit(f" mov [{self.base_reg}{offset}], al\n")
                    else:
                        self.emit(f" mov [{self.base_reg}{offset}], {self.main_reg}\n")
            elif var_name in self.global_variables:
                var_type, label, size = self.global_variables[var_name]
                if size == 1:
                    self.emit(f" mov [{label}], al\n")
                else:
                    self.emit(f" mov [{label}], {self.main_reg}\n")
                    
    def visit_IfNode(self, node):
        """Генерирует код для конструкции if-else"""
        else_label = self.get_label(".L_else")
        endif_label = self.get_label(".L_endif")
        
        # Вычисляем условие
        self.visit(node.condition)
        self.emit(f"    cmp {self.main_reg}, 0\n")
        
        if node.else_body:
            self.emit(f"    je {else_label}\n")
        else:
            self.emit(f"    je {endif_label}\n")
        
        # Тело if
        for stmt in node.if_body:
            self.visit(stmt)
        
        if node.else_body:
            self.emit(f"    jmp {endif_label}\n")
            self.emit(f"{else_label}:\n")
            for stmt in node.else_body:
                self.visit(stmt)
        
        self.emit(f"{endif_label}:\n")

    def visit_ComparisonNode(self, node):
        """Генерирует код для операций сравнения"""
        # Вычисляем операнды
        self.visit(node.right)
        self.emit(f"    push {self.main_reg}\n")
        
        self.visit(node.left)
        self.emit(f"    pop {self.temp_reg}\n")
        
        # Сравниваем
        self.emit(f"    cmp {self.main_reg}, {self.temp_reg}\n")
        
        true_label = self.get_label(".L_comp_true")
        end_label = self.get_label(".L_comp_end")
        
        # Выбираем правильный прыжок
        jump_map = {
            '==': 'je', '!=': 'jne', '<': 'jl', 
            '>': 'jg', '<=': 'jle', '>=': 'jge'
        }
        
        jump_inst = jump_map.get(node.op, 'je')
        self.emit(f"    {jump_inst} {true_label}\n")
        
        # False
        self.emit(f"    mov {self.main_reg}, 0\n")
        self.emit(f"    jmp {end_label}\n")
        
        # True
        self.emit(f"{true_label}:\n")
        self.emit(f"    mov {self.main_reg}, 1\n")
        self.emit(f"{end_label}:\n")
        
    def visit_UnaryOpNode(self, node):
        """Обрабатывает унарные операции"""
        self.visit(node.node)
        
        if node.op.type == TokenType.MINUS:
            self.emit(f"    neg {self.main_reg}\n")
        elif node.op.type == TokenType.PLUS:
            # Унарный плюс ничего не делает
            pass
        
    def visit_CharLiteralNode(self, node):
        """Генерирует код для символьных литералов"""
        self.emit(f"    mov {self.main_reg}, {node.value}\n")
        
    def visit_FloatLiteralNode(self, node):
        """Генерирует код для float литералов (упрощенно)"""
        # Для упрощения трактуем как целое число
        int_value = int(node.value)
        self.emit(f"    mov {self.main_reg}, {int_value} ; Float {node.value} as int\n")
        
    def visit_StructDeclarationNode(self, node):
        """Обрабатывает объявление структуры с поддержкой массивов структур"""
        if node.name in self.struct_definitions:
            raise NameError(f"Struct '{node.name}' is already defined")

        current_offset = 0
        struct_fields = {}

        for field_info in node.fields:
            if len(field_info) == 3:  # Массив в структуре
                field_type, field_name, array_size = field_info
                
                # НОВОЕ: Поддержка массивов структур
                if field_type in self.struct_definitions:
                    # Это массив структур
                    element_size = self.struct_definitions[field_type]['size']
                else:
                    # Примитивный тип
                    element_size = self.get_type_size(field_type)
                
                total_field_size = element_size * array_size
                
                struct_fields[field_name] = {
                    'type': f"{field_type}[{array_size}]",
                    'offset': current_offset,
                    'size': total_field_size,
                    'array_size': array_size,
                    'element_type': field_type,
                    'element_size': element_size  # НОВОЕ: для структур
                }
            else:  # Обычное поле
                field_type, field_name = field_info
                
                # НОВОЕ: Поддержка полей-структур
                if field_type in self.struct_definitions:
                    field_size = self.struct_definitions[field_type]['size']
                else:
                    field_size = self.get_type_size(field_type)
                
                struct_fields[field_name] = {
                    'type': field_type,
                    'offset': current_offset,
                    'size': field_size
                }
            
            current_offset += struct_fields[field_name]['size']

        self.struct_definitions[node.name] = {
            'size': current_offset,
            'fields': struct_fields
        }

        self.emit(f"; Struct {node.name} defined: size={current_offset} bytes\n")
        
    def visit_PropertyAccessNode(self, node):
        """Обрабатывает доступ к полям структуры (включая через указатели)"""
        var_name = node.variable_name
        field_name = node.property_name
        
        # Проверяем специальные свойства как .length
        if field_name == "length":
            if var_name not in self.array_sizes:
                raise NameError(f"Cannot get .length of '{var_name}', not a known array")
            array_length = self.array_sizes[var_name]
            self.emit(f" mov {self.main_reg}, {array_length}\n")
            return
        
        # Получаем информацию о переменной
        var_info = self.get_var_info(var_name)
        if not var_info:
            raise NameError(f"Variable '{var_name}' not defined")
        
        var_type, location, _ = var_info
        
        # НОВОЕ: Проверяем, является ли это указателем на структуру
        is_pointer_to_struct = False
        struct_type_name = var_type
        
        if var_type.endswith('*'):
            # Это указатель - получаем базовый тип
            struct_type_name = var_type[:-1]  # Убираем '*'
            is_pointer_to_struct = True
        
        if struct_type_name not in self.struct_definitions:
            raise TypeError(f"Variable '{var_name}' is not a struct or pointer to struct")
        
        struct_def = self.struct_definitions[struct_type_name]
        if field_name not in struct_def['fields']:
            raise NameError(f"Struct '{struct_type_name}' has no field '{field_name}'")
        
        field_info = struct_def['fields'][field_name]
        field_offset = field_info['offset']
        field_size = field_info['size']
        
        if is_pointer_to_struct:
            # НОВОЕ: Доступ через указатель
            # 1. Загружаем адрес структуры из указателя
            if isinstance(location, int):  # Локальная переменная-указатель
                if location > 0:
                    self.emit(f" mov {self.temp_reg}, [{self.base_reg}+{location}]\n")
                else:
                    self.emit(f" mov {self.temp_reg}, [{self.base_reg}{location}]\n")
            else:  # Глобальная переменная-указатель
                self.emit(f" mov {self.temp_reg}, [{location}]\n")
            
            # 2. Добавляем смещение поля
            if field_offset > 0:
                self.emit(f" add {self.temp_reg}, {field_offset}\n")
            
            # 3. Загружаем значение поля
            if 'array_size' in field_info:
                # Для массивов возвращаем адрес
                self.emit(f" mov {self.main_reg}, {self.temp_reg}\n")
            else:
                # Для обычных полей загружаем значение
                if field_size == 1:
                    self.emit(f" xor {self.main_reg}, {self.main_reg}\n")
                    self.emit(f" mov al, [{self.temp_reg}]\n")
                elif field_size == 2:
                    self.emit(f" mov {self.main_reg}, [{self.temp_reg}]\n")
                else:
                    size_prefix = 'word' if self.target_bits == 16 else 'dword'
                    self.emit(f" mov {self.main_reg}, {size_prefix} [{self.temp_reg}]\n")
        else:
            # Существующая логика для прямого доступа к структурам
            if 'array_size' in field_info:
                # Это массив - возвращаем его адрес
                if isinstance(location, int):  # Локальная структура
                    total_offset = location + field_offset
                    if total_offset > 0:
                        self.emit(f" lea {self.main_reg}, [{self.base_reg}+{total_offset}]\n")
                    else:
                        self.emit(f" lea {self.main_reg}, [{self.base_reg}{total_offset}]\n")
                else:  # Глобальная структура
                    if field_offset > 0:
                        self.emit(f" lea {self.main_reg}, [{location}+{field_offset}]\n")
                    else:
                        self.emit(f" mov {self.main_reg}, {location}\n")
            else:
                # Обычное поле - загружаем значение
                if isinstance(location, int):  # Локальная структура
                    total_offset = location + field_offset
                    if field_size == 1:
                        self.emit(f" xor {self.main_reg}, {self.main_reg}\n")
                        if total_offset > 0:
                            self.emit(f" mov al, [{self.base_reg}+{total_offset}]\n")
                        else:
                            self.emit(f" mov al, [{self.base_reg}{total_offset}]\n")
                    else:
                        if total_offset > 0:
                            self.emit(f" mov {self.main_reg}, [{self.base_reg}+{total_offset}]\n")
                        else:
                            self.emit(f" mov {self.main_reg}, [{self.base_reg}{total_offset}]\n")
                else:  # Глобальная структура
                    if field_size == 1:
                        self.emit(f" xor {self.main_reg}, {self.main_reg}\n")
                        if field_offset > 0:
                            self.emit(f" mov al, [{location}+{field_offset}]\n")
                        else:
                            self.emit(f" mov al, [{location}]\n")
                    else:
                        if field_offset > 0:
                            self.emit(f" mov {self.main_reg}, [{location}+{field_offset}]\n")
                        else:
                            self.emit(f" mov {self.main_reg}, [{location}]\n")
            
    def visit_MatchNode(self, node):
        """Генерирует код для match-case конструкции"""
        # Вычисляем выражение для сравнения
        self.visit(node.expression_node)
        self.emit(f" push {self.main_reg} ; Save match expression\n")

        end_label = self.get_label(".L_match_end")
        case_labels = []
        
        # Создаем метки для каждого case
        for i, case in enumerate(node.cases):
            if not case.is_default:
                case_labels.append(self.get_label(f".L_case_{i}"))

        # Генерируем сравнения
        for i, case in enumerate(node.cases):
            if not case.is_default:
                self.emit(f" mov {self.main_reg}, [{self.stack_reg}] ; Restore match expression\n")
                
                # Вычисляем значение case
                self.visit(case.value_node)
                self.emit(f" cmp [{self.stack_reg}], {self.main_reg}\n")
                self.emit(f" je {case_labels[i]}\n")

        # Default case (если есть)
        default_case = next((c for c in node.cases if c.is_default), None)
        if default_case:
            for stmt in default_case.body:
                self.visit(stmt)
        
        self.emit(f" jmp {end_label}\n")

        # Генерируем тела case'ов
        for i, case in enumerate(node.cases):
            if not case.is_default:
                self.emit(f"{case_labels[i]}:\n")
                for stmt in case.body:
                    self.visit(stmt)
                self.emit(f" jmp {end_label}\n")

        self.emit(f"{end_label}:\n")
        self.emit(f" add {self.stack_reg}, {2 if self.target_bits == 16 else 4} ; Clean match stack\n")
        
    def visit_StructArrayAccessNode(self, node):
        """Обрабатывает доступ к элементу массива поля структуры"""
        # Вычисляем индекс
        self.visit(node.index_node)
        self.emit(f" push {self.main_reg} ; Save index\n")
        
        # Получаем информацию о структуре
        struct_info = self.get_var_info(node.struct_name)
        if not struct_info:
            raise NameError(f"Struct variable '{node.struct_name}' not defined")
        
        struct_type, struct_location, _ = struct_info
        
        if struct_type not in self.struct_definitions:
            raise TypeError(f"Variable '{node.struct_name}' is not a struct")
        
        struct_def = self.struct_definitions[struct_type]
        if node.field_name not in struct_def['fields']:
            raise NameError(f"Struct '{struct_type}' has no field '{node.field_name}'")
        
        field_info = struct_def['fields'][node.field_name]
        field_offset = field_info['offset']
        
        # Получаем базовый адрес поля
        if isinstance(struct_location, int):  # Локальная структура
            total_offset = struct_location + field_offset
            if total_offset > 0:
                self.emit(f" lea {self.temp_reg}, [{self.base_reg}+{total_offset}]\n")
            else:
                self.emit(f" lea {self.temp_reg}, [{self.base_reg}{total_offset}]\n")
        else:  # Глобальная структура
            if field_offset > 0:
                self.emit(f" lea {self.temp_reg}, [{struct_location}+{field_offset}]\n")
            else:
                self.emit(f" mov {self.temp_reg}, {struct_location}\n")
        
        # Добавляем индекс
        self.emit(f" pop {self.main_reg} ; Restore index\n")
        self.emit(f" add {self.temp_reg}, {self.main_reg} ; Add index (assuming byte array)\n")
        
        # Загружаем значение
        self.emit(f" xor {self.main_reg}, {self.main_reg}\n")
        self.emit(f" mov al, [{self.temp_reg}]\n")

    def get_var_info(self, var_name):
        """Получает информацию о переменной (локальной или глобальной)"""
        if var_name in self.local_variables:
            return self.local_variables[var_name]
        elif var_name in self.global_variables:
            return self.global_variables[var_name]
        else:
            return None

        
    