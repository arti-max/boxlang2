#!/usr/bin/python3

import sys;
import time;
from time import sleep;
from copy import deepcopy;
from os import system, getenv;

RED   = "\033[91m";
GREEN = "\033[92m";
CLEAR = "\033[0m";

T_INS   = 0x00;
T_INT   = 0x01;
T_LAB   = 0x02;
T_REG   = 0x03;
T_DREG  = 0x04;
T_ID    = 0x05;
T_ADDRB = 0x06;
T_ADDRW = 0x07;
T_ADDRH = 0x08;
T_BYTE  = 0x09;
T_STR   = 0x0A;
T_MCR   = 0x0B;
T_DREB  = 0x0C;
T_DREW  = 0x0D;
T_DREH  = 0x0E;
T_EOL   = 0x0F;
T_EOF   = 0x10;

ASTINS   = 0x00;
ASTBYTES = 0x01;
ASTRES   = 0x02;
ASTEOF   = 0x04;

HUMAN_TOKS = ["inst", "int", "label", "reg", "*reg", "id", "#addr", "@addr", "*addr", "byte", "string", "mcr", "eol", "eof"];
HUMAN_AST  = ["INST", "BYTES", "RESERVE", "BRK-HANDLER", "EOF"];

LET    = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_";
LETEXT = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxy0123456789z-_.";
DIG    = "0123456789";
WHI    = " \r\0\t";
DIGEXT = "0123456789ABCDEF";
KEY2   = [
  "mov", "nop", "int", "hlt", "add", "jmp", "inx", "dex",
  "je", "jne", "jc", "jnc", "js", "jn", "ji", "jni", "cmp",
  "jg", "jl", "lb", "lw", "trap", "jsr", "rts",
  "re", "rne", "rc", "rnc", "rs", "rn", "ri", "rni", "psh",
  "sb", "sw", "mul", "div", "sub", "lp", "pop",
  "ldds", "lddg", "stds", "stdg", "sti", "irts", "pow", "and",
  "ora", "xor", "sal", "sar", "rswp", "cif", "cfi", "addf32",
  "subf32", "mulf32", "divf32", "negf32", "lobb", "stbb", "lobw",
  "stbw", "lobd", "stbd", "ld", "sd", "jz", "jnz", "loadf",
  "loada", "not", "nrm", "zzdref", "goida", "powf32"
];
KEYR   = {
  "eax": 0x00, "ebx": 0x01, "ecx": 0x02, "edx": 0x03, "esi": 0x04, "egi": 0x05, "esp": 0x06, "ebp": 0x07,
  "e8": 0x08,  "e9": 0x09,  "e10": 0x0A, "e11": 0x0B, "e12": 0x0C, "e13": 0x0D, "e14": 0x0E, "e15": 0x0F,
  "e16": 0x10, "e17": 0x11, "e18": 0x12, "e19": 0x13, "e20": 0x14, "e21": 0x15, "e22": 0x16, "e23": 0x17,
  "e24": 0x18, "e25": 0x19, "e26": 0x1A, "e27": 0x1B, "e28": 0x1C, "e29": 0x1D, "e30": 0x1E, "e31": 0x1F,

  "r0": 0x00,  "r1": 0x01,  "r2": 0x02,  "r3": 0x03,  "r4": 0x04,  "r5": 0x05,  "r6": 0x06,  "r7": 0x07,
  "r8": 0x08,  "r9": 0x09,  "r10": 0x0A, "r11": 0x0B, "r12": 0x0C, "r13": 0x0D, "r14": 0x0E, "r15": 0x0F,
  "r16": 0x10, "r17": 0x11, "r18": 0x12, "r19": 0x13, "r20": 0x14, "r21": 0x15, "r22": 0x16, "r23": 0x17,
  "r24": 0x18, "r25": 0x19, "r26": 0x1A, "r27": 0x1B, "r28": 0x1C, "r29": 0x1D, "r30": 0x1E, "r31": 0x1F
};

# Little endian
AsWord = lambda a: ((a & 0xFF), (a >> 8));
As24   = lambda a: ((a & 0xFF), ((a >> 8) & 0xFF), (a >> 16));
As32   = lambda a: ((a & 0xFF), ((a >> 8) & 0xFF), ((a >> 16) & 0xFF), (a >> 24));

def PrintTokens(toks: list):
  for i,j in enumerate(toks):
    if (len(j) == 2):
      print(f"{i}: {HUMAN_TOKS[j[0]]} {j[1]}");
    elif (len(j) == 1):
      print(f"{i}: {HUMAN_TOKS[j[0]]}");

def PrintAst(toks: list):
  for i in toks:
    print(f"${hex(i[3])[2:].upper():0>4}: {HUMAN_AST[i[0]]} {i[1]} {i[2]}");

def PrintLabs(labs: dict):
  print("\nLabel symbols:");
  for i in labs:
    print(f"{i+':': <30}${hex(labs[i])[2:].upper():0>4}");

def ExportLabs(filename: str, labs: dict, output_file: str):
  with open(output_file, "w") as fl:
    for i in labs:
      fl.write(f"{i}	{hex(labs[i])[2:].upper():0>4}\n");

def ImportLabs(filename: str, labs: dict, import_file: str):
  with open(import_file, "r") as fl:
    for line in fl.read().split("\n"):
      if (line):
        symbol,val = line.split(chr(9));
        labs[symbol] = int(val, base=16);
  return labs;

def OffsetLabs(labs: dict, offset: int):
  for i in labs:
    labs[i] += offset;
  return labs;

def getFilePos(s: str, pos: int):
  la = 1; ca = 1; r = 0;
  while (r < pos):
    ca += 1;
    if (s[r] == "\n"):
      la += 1;
      ca = 1;
    r += 1;
  return la,ca;

def usage():
  print("kasm -- Kakashka Assembler 1.0 (but who cares about the version anyways)");
  print("Usage: kasm [OPTIONS] <file.asm> <file.bin>");
  print("Options:");
  print("  -h           Show help");
  print("  -o [VAL]     Offset labels to VAL");
  print("  -i <file>    Import labels from a file");
  print("  -e           Export labels to the output file");
  print("  -cpp         Enable C preprocessor");
  print("  -I           Start interactive mode");

# Lexer:
def Lex(prog: str, filename: str):
  prog += "\n\0";
  labelscope: str  = "";
  proglen:    int  = len(prog);
  linenum:    int  = 1;
  toks:       list = [];
  pos:        int  = 0;
  buf:        str  = "";
  while (True):
    if (prog[pos] == "\0"):
      toks.append((T_EOL,));
      toks.append((T_EOF,));
      return toks, 0;
    elif (prog[pos] == ";"):
      pos += 1;
      while (prog[pos] != "\n"):
        pos += 1;
    elif ((prog[pos] == "/") and (prog[pos+1] == "/")):
      pos += 1;
      while (prog[pos] != "\n"):
        pos += 1;
    elif ((prog[pos] == "/") and (prog[pos+1] == "*")):
      pos += 1;
      while ((prog[pos] != "*") or (prog[pos+1] != "/")):
        pos += 1;
      pos += 2;
    elif (prog[pos] in WHI):
      pos += 1;
    elif (prog[pos] == "\n"):
      if ((toks) and (toks[-1][0] != T_EOL)):
        toks.append((T_EOL,));
      pos += 1;
      linenum += 1;
    elif (prog[pos] in "."): # Local label
      pos += 1;
      while (prog[pos] in LETEXT):
        buf += prog[pos];
        pos += 1;
      if (prog[pos] == ":"):
        toks.append((T_LAB, labelscope+"."+buf));
        pos += 1;
      else:
        toks.append((T_ID, labelscope+"."+buf));
      buf = "";
    elif (prog[pos] in "%"):
      pos += 1;
      while (prog[pos] in LETEXT):
        buf += prog[pos];
        pos += 1;
      pos += 1;
      if (buf in KEYR):
        toks.append((T_REG, KEYR[buf]));
      else:
        l,c = getFilePos(prog, pos);
        print(f"%s:%d:%d: {RED}error{CLEAR}: Bad register name `%s`" % (filename, l, c-2-len(buf), buf));
        exit(1);
      buf = "";
      pos -= 1;
    elif (prog[pos] in DIG):
      while (prog[pos] in DIG):
        buf += prog[pos];
        pos += 1;
      toks.append((T_INT, int(buf, base=10)));
      buf = "";
    elif (prog[pos] == "\""):
      pos += 1;
      while (prog[pos] != "\""):
        if (prog[pos] == "$"):
          buf += "\n";
        elif (prog[pos] == "\n"):
          print(f"kasm: {filename}:{linenum}:1: Unterminated string literal");
          exit(1);
        elif ((prog[pos] == "\\") and (prog[pos+1] == "\"")):
          buf += "\"";
          pos += 1;
        elif (prog[pos] == "^"):
          if (ord(prog[pos+1]) in range(64, 97)):
            buf += chr(ord(prog[pos+1])-64);
          elif (prog[pos+1] in "^$"):
            buf += prog[pos+1];
          pos += 1;
        else:
          buf += prog[pos];
        pos += 1;
      pos += 1;
      toks.append((T_STR, buf.encode()));
      buf = "";
    elif (prog[pos] == "'"):
      pos += 1;
      if (prog[pos] == "$"):
        buf = 10;
      elif ((prog[pos] == "\\") and (prog[pos+1] == "\"")):
        buf = 34;
        pos += 2;
      elif (prog[pos] == "^"):
        if (ord(prog[pos+1]) in range(64, 97)):
          buf = ord(prog[pos+1])-64;
        elif (prog[pos+1] in "^$"):
          buf = ord(prog[pos+1]);
        pos += 1;
      else:
        buf = ord(prog[pos]);
      pos += 1;
      if (prog[pos] != "'"):
        print(f"kasm: {filename}:{linenum}:1: Unterminated character literal");
        exit(1);
      pos += 1;
      toks.append((T_INT, buf));
      buf = "";
    elif (prog[pos] == "^"):
      pos += 1;
      while (prog[pos] in DIGEXT):
        buf += prog[pos];
        pos += 1;
      pos += 1;
      toks.append((T_INT, int(buf, base=16)));
      buf = "";
      # cpos += 1;
    elif (prog[pos] == "$"):
      pos += 1;
      while (prog[pos] in DIGEXT):
        buf += prog[pos];
        pos += 1;
      toks.append((T_INT, int(buf, base=16)));
      buf = "";
    elif (prog[pos] == "#"):
      pos += 1;
      if (prog[pos] in DIGEXT):
        while (prog[pos] in DIGEXT):
          buf += prog[pos];
          pos += 1;
        toks.append((T_ADDRB, int(buf, base=16)));
      else:
        while (prog[pos] in LET):
          buf += prog[pos];
          pos += 1;
        toks.append((T_DREB, buf));
      buf = "";
    elif (prog[pos] == "@"):
      pos += 1;
      if (prog[pos] in DIGEXT):
        while (prog[pos] in DIGEXT):
          buf += prog[pos];
          pos += 1;
        toks.append((T_ADDRW, int(buf, base=16)));
      else:
        while (prog[pos] in LET):
          buf += prog[pos];
          pos += 1;
        toks.append((T_DREW, buf));
      buf = "";
    elif (prog[pos] == "*"):
      pos += 1;
      regop = 0;
      if (prog[pos] == "%"):
        regop = 1;
        pos += 1;
      while (prog[pos] in LETEXT):
        buf += prog[pos];
        pos += 1;
      if (regop): # Dereferncing a register bro what :/
        toks.append((T_DREG, KEYR.index(buf)));
      else:
        toks.append((T_ID, buf));
      buf = "";
    elif (prog[pos] in LET):
      while (prog[pos] in LETEXT):
        buf += prog[pos];
        pos += 1;
      if (prog[pos] == ":"):
        toks.append((T_LAB, buf));
        labelscope = buf;
        pos += 1;
      else:
        if (buf in KEY2):
          toks.append((T_INS, buf));
        elif (buf == "bytes"):
          toks.append((T_BYTE, 0));
        elif (buf == "reserve"):
          toks.append((T_MCR, "reserve"));
        elif (buf == "extern"):
          toks.append((T_MCR, "extern"));
        else:
          toks.append((T_ID, buf));
      buf = "";
    else:
      l,c = getFilePos(prog, pos);
      print(f"%s:%d:%d: {RED}error{CLEAR}: bad character `%c`" % (filename, l, c, prog[pos]));
      exit(1);
  return [], 1;

def FetchLabels(prog: list, disk: bool):
  labs = dict();
  for i in prog:
    if (i[0] == T_LAB):
      labs[i[1]] = i[2]+(0x090000*disk);
  return labs;

def RemComments(prog: str):
  return "\n".join([i for i in prog.split("\n") if not i.startswith("# ")]);

ParseInst = lambda toks, b, pos, pc: \
  ((ASTINS, "MOVri", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "mov") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "MOVrl", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "mov") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_ID)) else
   (ASTINS, "MOVrb", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "mov") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_ADDRB)) else
   (ASTINS, "MOVrw", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "mov") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_ADDRW)) else
   (ASTINS, "MOVbr", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "mov") and (toks[pos+1][0] == T_ADDRB) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "MOVwr", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "mov") and (toks[pos+1][0] == T_ADDRW) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "MOVrc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "mov") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "MOVra", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "mov") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_ID)) else
   (ASTINS, "INT8",  toks[pos+1][1], pos + 2, pc + 2)                   if ((b == "int") and (toks[pos+1][0] == T_INT)) else
   (ASTINS, "POPr",  toks[pos+1][1], pos + 2, pc + 2)                   if ((b == "pop") and (toks[pos+1][0] == T_REG)) else
   (ASTINS, "RSWP",  0, pos + 1, pc + 2)                                if (b == "rswp") else
   (ASTINS, "HLT",   0, pos + 1, pc + 2)                                if (b == "hlt") else
   (ASTINS, "ADDri", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "add") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "ADDrl", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "add") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_ID)) else
   (ASTINS, "ADDrc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "add") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "ADDrb", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "add") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_ADDRB)) else
   (ASTINS, "ADDrw", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "add") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_ADDRW)) else
   (ASTINS, "ADDbr", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "add") and (toks[pos+1][0] == T_ADDRB) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "ADDwr", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "add") and (toks[pos+1][0] == T_ADDRW) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "SUBri", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "sub") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "SUBrc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "sub") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "MULri", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "mul") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "MULrc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "mul") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "DIVri", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "div") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "DIVrc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "div") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "ANDrc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "and") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "ORArc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "ora") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "XORrc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "xor") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "ANDri", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "and") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "ORAri", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "and") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "XORri", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "and") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "JMPa", toks[pos+1][1], pos + 2, pc + 6)                    if ((b == "jmp") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "JMPr", toks[pos+1][1], pos + 2, pc + 2)                    if ((b == "jmp") and (toks[pos+1][0] == T_REG)) else
   (ASTINS, "JMP2", toks[pos+1][1], pos + 2, pc + 6)                    if ((b == "jmp") and (toks[pos+1][0] == T_INT)) else
   (ASTINS, "JEa", toks[pos+1][1], pos + 2, pc + 6)                     if ((b == "jz") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "JEa", toks[pos+1][1], pos + 2, pc + 6)                     if ((b == "je") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "JNEa", toks[pos+1][1], pos + 2, pc + 6)                    if ((b == "jne") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "JNEa", toks[pos+1][1], pos + 2, pc + 6)                    if ((b == "jnz") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "JCa", toks[pos+1][1], pos + 2, pc + 6)                     if ((b == "jc") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "JNCa", toks[pos+1][1], pos + 2, pc + 6)                    if ((b == "jnc") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "JSa", toks[pos+1][1], pos + 2, pc + 6)                     if ((b == "js") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "JSa", toks[pos+1][1], pos + 2, pc + 6)                     if ((b == "jg") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "JNa", toks[pos+1][1], pos + 2, pc + 6)                     if ((b == "jn") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "JNa", toks[pos+1][1], pos + 2, pc + 6)                     if ((b == "jl") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "JIa", toks[pos+1][1], pos + 2, pc + 6)                     if ((b == "ji") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "JNIa", toks[pos+1][1], pos + 2, pc + 6)                    if ((b == "jni") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "LPa", toks[pos+1][1], pos + 2, pc + 6)                     if ((b == "lp") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "INXr",  toks[pos+1][1], pos + 2, pc + 2)                   if ((b == "inx") and (toks[pos+1][0] == T_REG)) else
   (ASTINS, "DEXr",  toks[pos+1][1], pos + 2, pc + 2)                   if ((b == "dex") and (toks[pos+1][0] == T_REG)) else
   (ASTINS, "INXb",  toks[pos+1][1], pos + 2, pc + 6)                   if ((b == "inx") and (toks[pos+1][0] == T_ADDRB)) else
   (ASTINS, "INXw",  toks[pos+1][1], pos + 2, pc + 6)                   if ((b == "inx") and (toks[pos+1][0] == T_ADDRW)) else
   (ASTINS, "DEXb",  toks[pos+1][1], pos + 2, pc + 6)                   if ((b == "dex") and (toks[pos+1][0] == T_ADDRB)) else
   (ASTINS, "DEXw",  toks[pos+1][1], pos + 2, pc + 6)                   if ((b == "dex") and (toks[pos+1][0] == T_ADDRW)) else
   (ASTINS, "JSRa", toks[pos+1][1], pos + 2, pc + 6)                    if ((b == "jsr") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "JSRr", toks[pos+1][1], pos + 2, pc + 2)                    if ((b == "jsr") and (toks[pos+1][0] == T_REG)) else
   (ASTINS, "JSR2", toks[pos+1][1], pos + 2, pc + 6)                    if ((b == "jsr") and (toks[pos+1][0] == T_INT)) else
   (ASTINS, "CMPri", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "cmp") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "CMPrl", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 6) if ((b == "cmp") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_ID)) else
   (ASTINS, "LBc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2)   if ((b == "lb") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "LWc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2)   if ((b == "lw") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "LDc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2)   if ((b == "ld") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "SBc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2)   if ((b == "sb") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "SWc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2)   if ((b == "sw") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "SDc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2)   if ((b == "sd") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "CMPrc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "cmp") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "TRAP", None, pos + 1, pc + 2)                              if (b == "trap") else
   (ASTINS, "RTS", None, pos + 2, pc + 2)                               if (b == "rts") else
   (ASTINS, "RE", None, pos + 1, pc + 2)                                if (b == "re") else
   (ASTINS, "RNE", None, pos + 1, pc + 2)                               if (b == "rne") else
   (ASTINS, "RC", None, pos + 1, pc + 2)                                if (b == "rc") else
   (ASTINS, "RNC", None, pos + 1, pc + 2)                               if (b == "rnc") else
   (ASTINS, "RS", None, pos + 1, pc + 2)                                if (b == "rs") else
   (ASTINS, "RS", None, pos + 1, pc + 2)                                if (b == "rg") else
   (ASTINS, "RN", None, pos + 1, pc + 2)                                if (b == "rn") else
   (ASTINS, "RN", None, pos + 1, pc + 2)                                if (b == "rl") else
   (ASTINS, "RI", None, pos + 1, pc + 2)                                if (b == "ri") else
   (ASTINS, "RNI", None, pos + 1, pc + 2)                               if (b == "rni") else
   (ASTINS, "PSHi", toks[pos+1][1], pos + 2, pc + 6)                    if ((b == "psh") and (toks[pos+1][0] == T_INT)) else
   (ASTINS, "PSHl", toks[pos+1][1], pos + 2, pc + 6)                    if ((b == "psh") and (toks[pos+1][0] == T_ID)) else
   (ASTINS, "PSHr", toks[pos+1][1], pos + 2, pc + 2)                    if ((b == "psh") and (toks[pos+1][0] == T_REG)) else
   (ASTINS, "LDDS", toks[pos+1][1], pos + 2, pc + 2)                    if (b == "ldds") and (toks[pos+1][0] == T_REG) else
   (ASTINS, "LDDG", toks[pos+1][1], pos + 2, pc + 2)                    if (b == "lddg") and (toks[pos+1][0] == T_REG) else
   (ASTINS, "STDS", toks[pos+1][1], pos + 2, pc + 2)                    if (b == "stds") and (toks[pos+1][0] == T_REG) else
   (ASTINS, "STDG", toks[pos+1][1], pos + 2, pc + 2)                    if (b == "stdg") and (toks[pos+1][0] == T_REG) else
   (ASTINS, "STI8", toks[pos+1][1], pos + 2, pc + 2)                    if ((b == "sti") and (toks[pos+1][0] == T_INT)) else
   (ASTINS, "NOTr", toks[pos+1][1], pos + 2, pc + 2)                    if ((b == "not") and (toks[pos+1][0] == T_REG)) else
   (ASTINS, "NRMr", toks[pos+1][1], pos + 2, pc + 2)                    if ((b == "nrm") and (toks[pos+1][0] == T_REG)) else
   (ASTINS, "IRTS", None, pos + 2, pc + 2)                              if (b == "irts") else
   (ASTINS, "INXbl", toks[pos+1][1], pos + 2, pc + 6)                   if ((b == "inx") and (toks[pos+1][0] == T_DREB)) else
   (ASTINS, "DEXbl", toks[pos+1][1], pos + 2, pc + 6)                   if ((b == "dex") and (toks[pos+1][0] == T_DREB)) else
   (ASTINS, "INXwl", toks[pos+1][1], pos + 2, pc + 6)                   if ((b == "inx") and (toks[pos+1][0] == T_DREW)) else
   (ASTINS, "DEXwl", toks[pos+1][1], pos + 2, pc + 6)                   if ((b == "dex") and (toks[pos+1][0] == T_DREW)) else
   (ASTINS, "POWrc", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "pow") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "LOBBg", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "lobb") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "STBBg", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "stbb") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "LOBWg", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "lobw") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "STBWg", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "stbw") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "LOBDg", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "lobd") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "STBDg", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "stbd") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "SALrg", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "sal") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "SARrg", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2) if ((b == "sar") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_INT)) else
   (ASTINS, "CIF", toks[pos+1][1], pos + 2, pc + 2)                     if ((b == "cif") and (toks[pos+1][0] == T_REG)) else
   (ASTINS, "CFI", toks[pos+1][1], pos + 2, pc + 2)                     if ((b == "cfi") and (toks[pos+1][0] == T_REG)) else
   (ASTINS, "NEGF", toks[pos+1][1], pos + 2, pc + 2)                    if ((b == "negf32") and (toks[pos+1][0] == T_REG)) else
   (ASTINS, "POWF", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2)  if ((b == "powf32") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "ADDF", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2)  if ((b == "addf32") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "SUBF", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2)  if ((b == "subf32") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "MULF", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2)  if ((b == "mulf32") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "DIVF", (toks[pos+1][1], toks[pos+2][1]), pos + 3, pc + 2)  if ((b == "divf32") and (toks[pos+1][0] == T_REG) and (toks[pos+2][0] == T_REG)) else
   (ASTINS, "NOP", (), pos + 1, pc + 2)                                 if ((b == "nop")) else
   (ASTINS, "ZZDRF", (), pos + 1, pc + 2)                               if ((b == "zzdref")) else
   (ASTINS, "LOADF", (), pos + 1, pc + 2)                               if ((b == "loadf")) else
   (ASTINS, "LOADA", (), pos + 1, pc + 2)                               if ((b == "loada")) else
   (print("kasm: unknown instruction", toks[pos]) and exit(1))
  );

# Parser:
def Parse(toks: list, filename: str, expm: int) -> list:
  labels: dict = {};
  ast:    list = [];
  pos:    int  = 0;
  pc:     int  = 0;
  while (toks[pos][0] != T_EOF):
    if (toks[pos][0] == T_INS): # Parse an instruction
      asttype, astvalue, astop, pos, newpc = ParseInst(toks, toks[pos][1], pos, pc);
      ast.append([asttype, astvalue, astop, pc]);
      pc = newpc;
    elif (toks[pos][0] == T_LAB): # Parse a label
      labels[toks[pos][1]] = pc;
      pos += 1;
    elif (toks[pos][0] == T_BYTE):
      ast.append([ASTBYTES, "__B_raw", [], pc]);
      pos += 1;
      while (toks[pos][0] != T_EOL):
        if (toks[pos][0] == T_INT):
          ast[-1][2].append(toks[pos][1]);
          pc += 1;
        elif (toks[pos][0] == T_ID):
          ast[-1][2].append(("l",toks[pos][1]));
          pc += 4;
        elif (toks[pos][0] == T_STR):
          for i in toks[pos][1]:
            ast[-1][2].append(i);
          pc += len(toks[pos][1]);
        else:
          print(f"{filename}:в ебенях: {RED}error{CLEAR}: token of type `{HUMAN_TOKS[toks[pos][0]]}` is placed in bytes definition.\nif this was a mistake, end the declaration by a newline character");
          exit(1);
        pos += 1;
      pos += 1;
    elif (toks[pos][0] == T_MCR): # Parse macros
      if (toks[pos][1] == "reserve"):
        if (toks[pos+1][0] != T_INT):
          print(f"{filename}:в ебенях: {RED}error{CLEAR}: expected number after reserve.");
          print(f"syntax for `reserve` is: reserve 10 bytes");
          exit(1);
        if (toks[pos+2][0] == T_BYTE):
          restype = 1; # bytes
        else:
          print(f"{filename}:в ебенях: {RED}error{CLEAR}: expected bytes after reserve #n.");
          print(f"syntax for `reserve` is: reserve 10 bytes");
          exit(1);
        ast.append([ASTRES, "__B_reserve", toks[pos+1][1]*restype, pc]);
        pc += toks[pos+1][1]*restype;
        pos += 3;
      elif (toks[pos][1] == "extern"):
        if (toks[pos+1][0] != T_STR):
          print(f"{filename}:в ебенях: {RED}error{CLEAR}: expected filename after extern.");
          print(f"syntax for `extern` is: extern \"filename\"");
          exit(1);
        with open(toks[pos+1][1], "rb") as extern_file:
          extern_source = extern_file.read()
        ast.append([ASTRES, "__B_extern", extern_source, pc]);
        pc += len(extern_source);
        pos += 2;
    elif (toks[pos][0] == T_EOL):
      pos += 1;
    else:
      print(f"{filename}:в ебенях: {RED}error{CLEAR}: unknown token: %s %s" % (HUMAN_TOKS[toks[pos][0]], toks[pos][1]));
      exit(1);
  ast.append([ASTEOF, 0, 0, pc]);
  if (expm):
    print(f"{GREEN}{filename}: exported {len(labels)} symbols{CLEAR}");
  else:
    print(f"{filename}: compiled {pc} bytes");
  return ast, labels;

CompileInst = lambda prog, b, labels, pos: \
  (((0xC0, b[2][0], *As32(b[2][1])), pos+1)         if (b[1] == "MOVri") else
   ((0xC0, b[2][0], *As32(labels[b[2][1]])), pos+1) if (b[1] == "MOVrl") else
   ((0xD0, b[2][0], *As32(b[2][1])), pos+1)         if (b[1] == "MOVrb") else
   ((0xD8, b[2][0], *As32(b[2][1])), pos+1)         if (b[1] == "MOVrw") else
   ((0xE0, b[2][1], *As32(b[2][0])), pos+1)         if (b[1] == "MOVbr") else
   ((0xE8, b[2][1], *As32(b[2][0])), pos+1)         if (b[1] == "MOVwr") else
   ((0xCF, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "MOVrc") else
   ((0xC0, b[2][0], *As32(labels[b[2][1]])), pos+1) if (b[1] == "MOVra") else
   ((0x41, b[2]), pos+1)                            if (b[1] == "INT8") else
   ((0xB6, b[2]), pos+1)                            if (b[1] == "POPr") else
   ((0x00,0x00), pos+1)                             if (b[1] == "HLT") else
   ((0xF0,0x00), pos+1)                             if (b[1] == "RSWP") else
   ((0x05,0x20), pos+1)                             if (b[1] == "NOP") else
   ((0x33,0x20), pos+1)                             if (b[1] == "ZZDRF") else
   ((0x0E,0x00), pos+1)                             if (b[1] == "LOADF") else
   ((0x0F,0x00), pos+1)                             if (b[1] == "LOADA") else
   ((0x48, b[2][0], *As32(b[2][1])), pos+1)         if (b[1] == "ADDri") else
   ((0x48, b[2][0], *As32(labels[b[2][1]])), pos+1) if (b[1] == "ADDrl") else
   ((0x47, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "ADDrc") else
   ((0x38, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "ANDrc") else
   ((0x39, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "ORArc") else
   ((0x3A, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "XORrc") else
   ((0x3B, b[2][0], *As32(b[2][1])), pos+1)         if (b[1] == "ANDri") else
   ((0x3C, b[2][0], *As32(b[2][1])), pos+1)         if (b[1] == "ORAri") else
   ((0x3D, b[2][0], *As32(b[2][1])), pos+1)         if (b[1] == "XORri") else
   ((0x50, b[2][0], *As32(b[2][1])), pos+1)         if (b[1] == "ADDrb") else
   ((0x58, b[2][0], *As32(b[2][1])), pos+1)         if (b[1] == "ADDrw") else
   ((0x60, b[2][1], *As32(b[2][0])), pos+1)         if (b[1] == "ADDbr") else
   ((0x68, b[2][1], *As32(b[2][0])), pos+1)         if (b[1] == "ADDwr") else
   ((0x86,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "JMPa") else
   ((0x87, b[2]), pos+1)                            if (b[1] == "JMPr") else
   ((0x86,0x00, *As32(b[2])), pos+1)                if (b[1] == "JMP2") else
   ((0xA0,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "JEa") else
   ((0xA1,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "JNEa") else
   ((0xA2,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "JCa") else
   ((0xA3,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "JNCa") else
   ((0xA4,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "JSa") else
   ((0xA5,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "JNa") else
   ((0xA6,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "JIa") else
   ((0xA7,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "JNIa") else
   ((0xB8,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "LPa") else
   ((0x10, b[2][0], *As32(b[2][1])), pos+1)         if (b[1] == "SUBri") else
   ((0xC8, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "SUBrc") else
   ((0x08, b[2][0], *As32(b[2][1])), pos+1)         if (b[1] == "MULri") else
   ((0xC9, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "MULrc") else
   ((0x80, b[2][0], *As32(b[2][1])), pos+1)         if (b[1] == "DIVri") else
   ((0xCA, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "DIVrc") else
   ((0x20, b[2],), pos+1)                           if (b[1] == "INXr") else
   ((0x28, b[2],), pos+1)                           if (b[1] == "DEXr") else
   ((0x30,0x00, *As32(b[2])), pos+1)                if (b[1] == "INXb") else
   ((0x40,0x00, *As32(b[2])), pos+1)                if (b[1] == "INXw") else
   ((0x32,0x00, *As32(b[2])), pos+1)                if (b[1] == "DEXb") else
   ((0x42,0x00, *As32(b[2])), pos+1)                if (b[1] == "DEXw") else
   ((0x34, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "GOIDA") else
   ((0x70, b[2][0], *As32(b[2][1])), pos+1)         if (b[1] == "CMPri") else
   ((0x70, b[2][0], *As32(labels[b[2][1]])), pos+1) if (b[1] == "CMPri") else
   ((0x37, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "CMPrc") else
   ((0x7F, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "LBc") else
   ((0x8F, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "LWc") else
   ((0x9F, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "LDc") else
   ((0x7E, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "SBc") else
   ((0x8E, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "SWc") else
   ((0x9E, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "SDc") else
   ((0x01,0x00), pos+1)                             if (b[1] == "TRAP") else
   ((0x79,0x00), pos+1)                             if (b[1] == "RTS") else
   ((0xA8,0x00), pos+1)                             if (b[1] == "RE") else
   ((0xA9,0x00), pos+1)                             if (b[1] == "RNE") else
   ((0xAA,0x00), pos+1)                             if (b[1] == "RC") else
   ((0xAB,0x00), pos+1)                             if (b[1] == "RNC") else
   ((0xAC,0x00), pos+1)                             if (b[1] == "RS") else
   ((0xAD,0x00), pos+1)                             if (b[1] == "RN") else
   ((0xAE,0x00), pos+1)                             if (b[1] == "RI") else
   ((0xAF,0x00), pos+1)                             if (b[1] == "RNI") else
   ((0xB0,0x00, *As32(b[2])), pos+1)                if (b[1] == "PSHi") else
   ((0xB0,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "PSHl") else
   ((0xB5, b[2]), pos+1)                            if (b[1] == "PSHr") else
   ((0x78,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "JSRa") else
   ((0x88, b[2]), pos+1)                            if (b[1] == "JSRr") else
   ((0x78,0x00, *As32(b[2])), pos+1)                if (b[1] == "JSR2") else
   ((0xB9,b[2]), pos+1)                             if (b[1] == "LDDS") else
   ((0xBA,b[2]), pos+1)                             if (b[1] == "LDDG") else
   ((0xBB,b[2]), pos+1)                             if (b[1] == "STDS") else
   ((0xBC,b[2]), pos+1)                             if (b[1] == "STDG") else
   ((0x03, b[2]), pos+1)                            if (b[1] == "STI8") else
   ((0x0C, b[2]), pos+1)                            if (b[1] == "NOTr") else
   ((0x0D, b[2]), pos+1)                            if (b[1] == "NRMr") else
   ((0x04,0x00), pos+1)                             if (b[1] == "IRTS") else
   ((0x40,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "INXwl") else
   ((0x42,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "DEXwl") else
   ((0x30,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "INXbl") else
   ((0x32,0x00, *As32(labels[b[2]])), pos+1)        if (b[1] == "DEXbl") else
   ((0xBF, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "POWrc") else
   ((0x7C, (b[2][0]<<5)+(b[2][1])), pos+1)          if (b[1] == "LOBBg") else
   ((0x7D, (b[2][0]<<5)+(b[2][1])), pos+1)          if (b[1] == "STBBg") else
   ((0x8C, (b[2][0]<<5)+(b[2][1])), pos+1)          if (b[1] == "LOBWg") else
   ((0x8D, (b[2][0]<<5)+(b[2][1])), pos+1)          if (b[1] == "STBWg") else
   ((0x9C, (b[2][0]<<5)+(b[2][1])), pos+1)          if (b[1] == "LOBDg") else
   ((0x9D, (b[2][0]<<5)+(b[2][1])), pos+1)          if (b[1] == "STBDg") else
   ((0x7A, (b[2][0]<<5)+(b[2][1])), pos+1)          if (b[1] == "SALrg") else
   ((0x7B, (b[2][0]<<5)+(b[2][1])), pos+1)          if (b[1] == "SARrg") else
   ((0xF8, b[2]), pos+1)                            if (b[1] == "CIF") else
   ((0xF9, b[2]), pos+1)                            if (b[1] == "CFI") else
   ((0xFE, b[2]), pos+1)                            if (b[1] == "NEGF") else
   ((0xFF, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "POWF") else
   ((0xFA, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "ADDF") else
   ((0xFB, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "SUBF") else
   ((0xFC, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "MULF") else
   ((0xFD, (b[2][0]<<4)+b[2][1]), pos+1)            if (b[1] == "DIVF") else
   [print("kasm: \033[91munknown compilation node %s\033[0m" % b[1]), (tuple(), 0x1_00_0000)][1]
  );

# Compiler:
def CompileGC32(prog: list, labs: dict):
  code = bytearray();
  pos = 0;
  while (prog[pos][0] != ASTEOF):
    if (prog[pos][0] == ASTINS):
      compbytes, pos = CompileInst(prog, prog[pos], labs, pos);
      if (pos == 0x1_00_0000): exit(1);
      code.extend(compbytes);
    elif (prog[pos][0] == ASTBYTES):
      p = deepcopy(prog[pos][2]);
      for i,j in enumerate(p):
        if (type(j) is tuple):
          prog[pos][2][i:i+1] = As32(labs[prog[pos][2][i][1]]);
      code.extend(prog[pos][2]);
      pos += 1;
    elif (prog[pos][0] == ASTRES):
      code.extend(bytes(prog[pos][2]));
      pos += 1;
    else:
      print("kasm: unknown ast node: %s" % HUMAN_AST[prog[pos][0]]);
      exit(1);
  return code, 0;

def IKasm() -> int:
  print("interactive kasm");
  while (1):
    cd = input(">>> \033[32m");
    if (not cd):
      print(end="\033[0m");
      continue;
    if (cd == "exit"):
      print(end="\033[0m");
      exit(0);
    print(end="\033[97m");
    tokens, exitcode = Lex(cd, "input");
    ast, labs = Parse(tokens, "input", False);
    labs = OffsetLabs(labs, 0x030000);
    c, exitcode = CompileGC32(ast, labs);
    print(end="\033[96m");
    for i in c:
      print(end="%02X " % i);
    print("\b\033[0m");
  exit(0);

def main(argc: int, argv: list) -> int:
  global RED, CLEAR;
  if (getenv("TERM") not in ["xterm", "xterm-256color"]):
    RED   = "";
    GREEN = "";
    CLEAR = "";

  diskmode = False;
  exportmode = False;
  cppmode = False;
  if (argc == 1):
    print("No arguments given");
    usage();
    return 1;
  # elif (argc == 2):
  #   print("No binary filename given");
  #   return 1;
  argp: int = 1;
  imp_files = [];
  offset = 0x030000;
  while (argp < argc):
    match (argv[argp]):
      case "-e":
        exportmode = 1;
        argp += 1;
      case "-i":
        imp_files.append(argv[argp+1]);
        argp += 2;
      case "-o":
        offset = int(argv[argp+1], base=16);
        argp += 2;
      case "-d":
        diskmode = True;
        argp += 1;
      case "-cpp":
        cppmode = True;
        argp += 1;
      case "-I":
        IKasm();
        argp += 1;
        break;
      case "-h":
        usage();
        return 0;
      case _:
        progname = argv[argp];
        outname = argv[argp+1];
        break;

  if (argc == 3):
    progname = argv[1];
    outname = argv[2];
  ofname = progname.split("/")[-1];

  if (cppmode):
    system(f"cpp {progname} /tmp/{ofname}.i");
    try:
      with open("/tmp/"+ofname+".i", "r") as fl:
        src = fl.read();
    except:
      print(f"kasm: {progname}: file not found");
      exit(1);
    src = RemComments(src)+"\0";
    system(f"rm /tmp/{ofname}.i");
  else:
    try:
      with open(progname, "r") as fl:
        src = fl.read()+"\0";
    except:
      print(f"kasm: {progname}: file not found");
      exit(1);

  tokens, exitcode = Lex(src, progname);
  if (type(tokens[1]) is int):
    print("Fatal error. Can't compile");
    exit(tokens);
  ast, labs = Parse(tokens, progname, exportmode);
  labs = OffsetLabs(labs, offset);
  # PrintLabs(labs);
  if (exportmode):
    ExportLabs(progname, labs, outname);
    exit(1);
  for imp_file in imp_files:
    labs = ImportLabs(progname, labs, imp_file);
  c, exitcode = CompileGC32(ast, labs);
  with open(outname, "wb") as fl:
    fl.write(c);

  return 0;

sys.exit(main(len(sys.argv), sys.argv));

