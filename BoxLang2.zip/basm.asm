BITS 16
ORG 0x8000

section .text

jmp _start
; Struct TextColors defined: size=4 bytes
; Struct VgaColors defined: size=16 bytes
; Struct Inst defined: size=39 bytes
; Struct Label defined: size=18 bytes
; Struct Define defined: size=18 bytes
; Struct Assembly defined: size=44554 bytes
init_all_colors_structs:
    push bp
    mov bp, sp
    mov ax, 1
 mov [_var_TEXT_COLORS], al
    mov ax, 2
 mov [_var_TEXT_COLORS+1], al
    mov ax, 3
 mov [_var_TEXT_COLORS+2], al
    mov ax, 4
 mov [_var_TEXT_COLORS+3], al
    mov ax, 0
 mov [_var_VGA_COLORS], al
    mov ax, 1
 mov [_var_VGA_COLORS+1], al
    mov ax, 2
 mov [_var_VGA_COLORS+2], al
    mov ax, 3
 mov [_var_VGA_COLORS+3], al
    mov ax, 4
 mov [_var_VGA_COLORS+4], al
    mov ax, 5
 mov [_var_VGA_COLORS+5], al
    mov ax, 6
 mov [_var_VGA_COLORS+6], al
    mov ax, 7
 mov [_var_VGA_COLORS+7], al
    mov ax, 8
 mov [_var_VGA_COLORS+8], al
    mov ax, 9
 mov [_var_VGA_COLORS+9], al
    mov ax, 10
 mov [_var_VGA_COLORS+10], al
    mov ax, 11
 mov [_var_VGA_COLORS+11], al
    mov ax, 12
 mov [_var_VGA_COLORS+12], al
    mov ax, 13
 mov [_var_VGA_COLORS+13], al
    mov ax, 14
 mov [_var_VGA_COLORS+14], al
    mov ax, 15
 mov [_var_VGA_COLORS+15], al
.init_all_colors_structs_end:
    mov sp, bp
    pop bp
    ret

init_text_mode:
    push bp
    mov bp, sp
    call init_all_colors_structs
; === NASM inline assembly start ===
    mov ah, 0x00
; === NASM inline assembly end ===
; === NASM inline assembly start ===
    int 0x21
; === NASM inline assembly end ===
.init_text_mode_end:
    mov sp, bp
    pop bp
    ret

clear_screen:
    push bp
    mov bp, sp
; === NASM inline assembly start ===
    mov ah, 0x06
; === NASM inline assembly end ===
; === NASM inline assembly start ===
    int 0x21
; === NASM inline assembly end ===
.clear_screen_end:
    mov sp, bp
    pop bp
    ret

print_newline:
    push bp
    mov bp, sp
; === NASM inline assembly start ===
    mov ah, 0x05
; === NASM inline assembly end ===
; === NASM inline assembly start ===
    int 0x21
; === NASM inline assembly end ===
.print_newline_end:
    mov sp, bp
    pop bp
    ret

set_text_color:
    push bp
    mov bp, sp
    mov ax, [bp+4]
 push ax ; Save nasmf arg 0 on stack
 pop ax ; Load nasmf arg 0
; === NASMF v1 inline assembly start ===
mov bx, ax
mov ah, 0x07
int 0x21
; === NASMF v1 inline assembly end ===
.set_text_color_end:
    mov sp, bp
    pop bp
    ret

print_string:
    push bp
    mov bp, sp
    mov ax, [bp+4]
 push ax ; Save nasmf arg 0 on stack
 pop ax ; Load nasmf arg 0
; === NASMF v1 inline assembly start ===
mov si, ax
mov ah, 0x08
int 0x21
; === NASMF v1 inline assembly end ===
.print_string_end:
    mov sp, bp
    pop bp
    ret

print_white_string:
    push bp
    mov bp, sp
    mov ax, [bp+4]
 push ax ; Save nasmf arg 0 on stack
 pop ax ; Load nasmf arg 0
; === NASMF v1 inline assembly start ===
mov si, ax
; === NASMF v1 inline assembly end ===
; === NASM inline assembly start ===
    mov ah, 0x01
; === NASM inline assembly end ===
; === NASM inline assembly start ===
    int 0x21
; === NASM inline assembly end ===
.print_white_string_end:
    mov sp, bp
    pop bp
    ret

init_prox_app:
    push bp
    mov bp, sp
    mov ax, [_var___argv_pointer]
 push ax ; Save nasmf arg 0 on stack
 pop ax ; Load nasmf arg 0
; === NASMF v1 inline assembly start ===
mov ax, si
; === NASMF v1 inline assembly end ===
; === NASM inline assembly start ===
    mov bx, ax
; === NASM inline assembly end ===
; === NASM inline assembly start ===
    mov [bx], si
; === NASM inline assembly end ===
.init_prox_app_end:
    mov sp, bp
    pop bp
    ret

reboot:
    push bp
    mov bp, sp
; === NASM inline assembly start ===
    int 0x19
; === NASM inline assembly end ===
.reboot_end:
    mov sp, bp
    pop bp
    ret

get_command_argv:
    push bp
    mov bp, sp
.get_command_argv_end:
    mov sp, bp
    pop bp
    ret

printf:
    push bp
    mov bp, sp
.printf_end:
    mov sp, bp
    pop bp
    ret

_start:
    push bp
    mov bp, sp
    sub sp, 44554
    call init_all_colors_structs
 xor ax, ax
 mov al, [_var_VGA_COLORS+15]
    push ax
    call set_text_color
    add sp, 2
 mov ax, _str_0
    push ax
    call print_string
    add sp, 2
 mov ax, _str_1
 lea di, [bp-128]
 mov si, ax
 mov cx, 128
 cld
 rep movsb
    lea ax, [bp-44554]
    push ax
    call print_error
    add sp, 2
._start_end:
    mov sp, bp
    pop bp
    ret

print_error:
    push bp
    mov bp, sp
 xor ax, ax
 mov al, [_var_VGA_COLORS+12]
    push ax
    call set_text_color
    add sp, 2
 mov bx, [bp+4]
 add bx, 44426
 mov ax, bx
    push ax
    call print_string
    add sp, 2
    call print_newline
 xor ax, ax
 mov al, [_var_VGA_COLORS+15]
    push ax
    call set_text_color
    add sp, 2
.print_error_end:
    mov sp, bp
    pop bp
    ret


; == DATA SECTION ==
_var_TEXT_COLORS: times 4 db 0 ; struct TextColors
_var_VGA_COLORS: times 16 db 0 ; struct VgaColors
_var___argv_pointer: dw 0
_str_0: db 83, 116, 97, 114, 116, 32, 97, 115, 115, 101, 109, 98, 108, 105, 110, 103, 46, 46, 46, 0
_str_1: db 69, 114, 114, 111, 114, 58, 32, 84, 101, 115, 116, 32, 69, 114, 114, 111, 114, 0
